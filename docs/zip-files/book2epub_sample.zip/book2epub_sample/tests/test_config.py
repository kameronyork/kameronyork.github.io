from pathlib import Path

from book2epub_vision.config import load_config


def test_config_paths_resolve_relative_to_config(tmp_path: Path) -> None:
    cfg_dir = tmp_path / "examples"
    cfg_dir.mkdir()
    input_dir = tmp_path / "input"
    input_dir.mkdir()
    pdf = input_dir / "chapter.pdf"
    pdf.write_bytes(b"fake")

    config_path = cfg_dir / "book.json"
    config_path.write_text(
        """
        {
          "title": "T",
          "author": "A",
          "language": "en",
          "identifier": "id",
          "render_dpi": 300,
          "ocr_engine": "surya",
          "layout_engine": "surya",
          "work_dir": "../work/book",
          "output_epub": "../output/book.epub",
          "crop_model": {},
          "cleanup": {},
          "chapters": [
            {"id": "c1", "title": "C1", "pdf": "../input/chapter.pdf"}
          ]
        }
        """,
        encoding="utf-8",
    )

    cfg = load_config(config_path)
    assert cfg.chapters[0].pdf == pdf.resolve()
    assert cfg.work_dir == (tmp_path / "work" / "book").resolve()
