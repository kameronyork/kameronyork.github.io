from book2epub_vision.ai_crop import compute_body_crop_box
from book2epub_vision.models import CropModelConfig


def test_compute_body_crop_box_merges_boxes_and_adds_margin() -> None:
    config = CropModelConfig(margin_px=10, min_box_area_ratio=0.0, max_boxes=10)
    page = {
        "bboxes": [
            {"bbox": [100, 200, 500, 260]},
            {"bbox": [110, 270, 510, 330]},
        ]
    }
    box = compute_body_crop_box(1000, 1500, page, config)
    assert box == (90, 190, 520, 340)


def test_compute_body_crop_box_returns_full_page_when_no_boxes() -> None:
    config = CropModelConfig()
    page = {"bboxes": []}
    assert compute_body_crop_box(900, 1200, page, config) == (0, 0, 900, 1200)
