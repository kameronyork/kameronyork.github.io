from __future__ import annotations

import json
import tkinter as tk
from dataclasses import dataclass
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any

from PIL import Image, ImageDraw, ImageTk

from .ai_crop import BBox, deserialize_box, load_chapter_crop_state, save_chapter_crop_state


try:
    RESAMPLE_LANCZOS = Image.Resampling.LANCZOS
except AttributeError:  # Pillow < 9
    RESAMPLE_LANCZOS = Image.LANCZOS


CROP_REVIEW_MANIFEST_FILENAME = "crop_review_manifest.json"

BG = "#f3f6fb"
CARD_BG = "#ffffff"
CARD_BORDER = "#d8dfeb"
TEXT = "#1f2937"
MUTED = "#6b7280"
ACCENT = "#4f46e5"
ACCENT_DARK = "#4338ca"
SUCCESS = "#10b981"
SUCCESS_DARK = "#059669"
WARNING = "#f59e0b"
DANGER = "#ef4444"
CANVAS_BG = "#111827"
PREVIEW_BG = "#0f172a"
OUTLINE_PENDING = "#60a5fa"
OUTLINE_APPROVED = "#22c55e"
OUTLINE_EDIT = "#f59e0b"


@dataclass(slots=True)
class ReviewPage:
    chapter_id: str
    chapter_title: str
    state_path: Path
    page_name: str
    page_path: Path
    cropped_path: Path
    image_width: int
    image_height: int
    suggested_box: BBox
    approved_box: BBox | None
    status: str


def crop_review_manifest_path(work_dir: Path) -> Path:
    return work_dir / CROP_REVIEW_MANIFEST_FILENAME


def save_crop_review_manifest(work_dir: Path, chapters: list[dict[str, str]]) -> Path:
    payload = {
        "version": 1,
        "chapters": chapters,
    }
    path = crop_review_manifest_path(work_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def load_crop_review_manifest(manifest_path: Path) -> dict[str, Any]:
    raw = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"Invalid crop review manifest: {manifest_path}")
    return raw


def launch_crop_review_app(manifest_path: str | Path) -> Path:
    manifest_path = Path(manifest_path).resolve()
    app = CropReviewApp(manifest_path)
    app.run()
    return manifest_path


def _box_size(box: BBox | None) -> tuple[int, int]:
    if box is None:
        return (0, 0)
    return (max(0, box[2] - box[0]), max(0, box[3] - box[1]))


def _resize_copy(image: Image.Image, max_width: int, max_height: int) -> Image.Image:
    max_width = max(1, max_width)
    max_height = max(1, max_height)

    resized = image.copy()
    resized.thumbnail((max_width, max_height), RESAMPLE_LANCZOS)
    return resized


class CropReviewApp:
    def __init__(self, manifest_path: Path) -> None:
        self.manifest_path = manifest_path
        self.manifest = load_crop_review_manifest(manifest_path)
        self.pages = self._load_pages()
        self.current_index = self._initial_index()

        if not self.pages:
            raise RuntimeError(f"No pages found in crop review manifest: {manifest_path}")

        self.root = tk.Tk()
        self.root.title("Crop Review Studio")
        self.root.geometry("1480x980")
        self.root.minsize(1080, 760)
        self.root.configure(background=BG)

        self.browser_window: PageBrowserWindow | None = None
        self.current_image: Image.Image | None = None
        self.tk_image: ImageTk.PhotoImage | None = None
        self.crop_preview_image: ImageTk.PhotoImage | None = None
        self.cached_display_size: tuple[int, int] | None = None
        self.current_box: BBox | None = None
        self.previous_box_before_edit: BBox | None = None
        self.edit_mode = False
        self.drag_start: tuple[int, int] | None = None
        self.scale = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.page_dirty = False
        self.all_done_notified = False

        self.progress_var = tk.StringVar(value="")
        self.status_var = tk.StringVar(value="")
        self.help_var = tk.StringVar(value="")
        self.chapter_var = tk.StringVar(value="")
        self.page_var = tk.StringVar(value="")
        self.box_var = tk.StringVar(value="")
        self.crop_preview_var = tk.StringVar(value="")
        self.badge_var = tk.StringVar(value="")
        self.shortcuts_var = tk.StringVar(
            value="Shortcuts: Enter approve  •  U unapprove  •  E edit  •  R reset to suggestion  •  ←/→ navigate  •  B open browser  •  Esc cancel edit"
        )

        self._configure_style()
        self._build_layout()
        self._bind_events()

        self.root.after(10, self._show_current_page)
        self.root.after(180, self.open_browser_window)

    def run(self) -> None:
        self.root.mainloop()

    def _configure_style(self) -> None:
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("App.TFrame", background=BG)
        style.configure("Card.TFrame", background=CARD_BG, borderwidth=1, relief="solid")
        style.configure("CardInner.TFrame", background=CARD_BG)
        style.configure("Title.TLabel", background=BG, foreground=TEXT, font=("TkDefaultFont", 20, "bold"))
        style.configure("Subtitle.TLabel", background=BG, foreground=MUTED, font=("TkDefaultFont", 10))
        style.configure("CardTitle.TLabel", background=CARD_BG, foreground=TEXT, font=("TkDefaultFont", 11, "bold"))
        style.configure("CardBody.TLabel", background=CARD_BG, foreground=TEXT, font=("TkDefaultFont", 10))
        style.configure("MutedCard.TLabel", background=CARD_BG, foreground=MUTED, font=("TkDefaultFont", 10))
        style.configure("StrongCard.TLabel", background=CARD_BG, foreground=TEXT, font=("TkDefaultFont", 12, "bold"))
        style.configure("Accent.TButton", background=ACCENT, foreground="#ffffff", padding=(14, 8), relief="flat")
        style.map(
            "Accent.TButton",
            background=[("pressed", ACCENT_DARK), ("active", ACCENT_DARK)],
            foreground=[("disabled", "#d1d5db"), ("!disabled", "#ffffff")],
        )
        style.configure("Secondary.TButton", background="#e8eefc", foreground=ACCENT, padding=(12, 8), relief="flat")
        style.map(
            "Secondary.TButton",
            background=[("pressed", "#dbe4ff"), ("active", "#dbe4ff")],
            foreground=[("!disabled", ACCENT)],
        )
        style.configure("Ghost.TButton", background="#f8fafc", foreground=TEXT, padding=(12, 8), relief="flat")
        style.map(
            "Ghost.TButton",
            background=[("pressed", "#eef2f7"), ("active", "#eef2f7")],
            foreground=[("!disabled", TEXT)],
        )
        style.configure("Treeview", background="#ffffff", foreground=TEXT, fieldbackground="#ffffff", rowheight=28)
        style.configure("Treeview.Heading", background="#eef2ff", foreground=TEXT, relief="flat", font=("TkDefaultFont", 10, "bold"))
        style.map("Treeview", background=[("selected", "#dde7ff")], foreground=[("selected", TEXT)])
        style.configure("TNotebook", background=CARD_BG, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(12, 8), background="#edf2ff", foreground=TEXT)
        style.map("TNotebook.Tab", background=[("selected", CARD_BG), ("active", "#e2e8f0")])
        style.configure("TCombobox", fieldbackground="#ffffff", background="#ffffff")
        style.configure("Horizontal.TProgressbar", troughcolor="#e5e7eb", background=ACCENT, bordercolor="#e5e7eb")

    def _build_layout(self) -> None:
        self.root.rowconfigure(0, weight=1)
        self.root.columnconfigure(0, weight=1)

        main = ttk.Frame(self.root, style="App.TFrame", padding=(18, 18, 18, 18))
        main.grid(row=0, column=0, sticky="nsew")
        main.rowconfigure(2, weight=1)
        main.columnconfigure(0, weight=1)

        header = ttk.Frame(main, style="App.TFrame")
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)

        title_group = ttk.Frame(header, style="App.TFrame")
        title_group.grid(row=0, column=0, sticky="w")
        ttk.Label(title_group, text="Crop Review Studio", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            title_group,
            text="Approve or refine every proposed crop before the long OCR run starts.",
            style="Subtitle.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(2, 0))

        header_actions = ttk.Frame(header, style="App.TFrame")
        header_actions.grid(row=0, column=1, sticky="e")
        ttk.Button(header_actions, text="Open Page Browser", style="Secondary.TButton", command=self.open_browser_window).grid(
            row=0, column=0, padx=(0, 8)
        )
        ttk.Button(header_actions, text="Close", style="Ghost.TButton", command=self.close).grid(row=0, column=1)

        progress_card = ttk.Frame(main, style="Card.TFrame", padding=(14, 12, 14, 12))
        progress_card.grid(row=1, column=0, sticky="ew", pady=(14, 14))
        progress_card.columnconfigure(0, weight=1)
        ttk.Label(progress_card, textvariable=self.progress_var, style="StrongCard.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(progress_card, textvariable=self.status_var, style="MutedCard.TLabel").grid(row=1, column=0, sticky="w", pady=(2, 8))
        self.progress_bar = ttk.Progressbar(progress_card, mode="determinate")
        self.progress_bar.grid(row=2, column=0, sticky="ew")

        content = ttk.Frame(main, style="App.TFrame")
        content.grid(row=2, column=0, sticky="nsew")
        content.rowconfigure(0, weight=1)
        content.columnconfigure(0, weight=5)
        content.columnconfigure(1, weight=2)

        viewer_card = ttk.Frame(content, style="Card.TFrame", padding=(12, 12, 12, 12))
        viewer_card.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        viewer_card.rowconfigure(0, weight=1)
        viewer_card.columnconfigure(0, weight=1)

        self.canvas = tk.Canvas(viewer_card, background=CANVAS_BG, highlightthickness=0, bd=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")

        toolbar = ttk.Frame(viewer_card, style="CardInner.TFrame")
        toolbar.grid(row=1, column=0, sticky="ew", pady=(12, 0))
        toolbar.columnconfigure(3, weight=1)

        self.back_button = ttk.Button(toolbar, text="◀ Back", style="Ghost.TButton", command=self.go_previous)
        self.back_button.grid(row=0, column=0, padx=(0, 8))

        self.next_button = ttk.Button(toolbar, text="Next ▶", style="Ghost.TButton", command=self.go_next)
        self.next_button.grid(row=0, column=1, padx=(0, 8))

        self.browser_button = ttk.Button(toolbar, text="Browse Pages", style="Secondary.TButton", command=self.open_browser_window)
        self.browser_button.grid(row=0, column=2, padx=(0, 8))

        self.reset_button = ttk.Button(toolbar, text="Reset to Suggestion", style="Ghost.TButton", command=self.reset_to_suggestion)
        self.reset_button.grid(row=0, column=4, padx=(8, 8))

        self.edit_button = ttk.Button(toolbar, text="Edit", style="Secondary.TButton", command=self.enable_edit_mode)
        self.edit_button.grid(row=0, column=5, padx=(0, 8))

        self.unapprove_button = ttk.Button(toolbar, text="Unapprove", style="Ghost.TButton", command=self.unapprove_current)
        self.unapprove_button.grid(row=0, column=6, padx=(0, 8))

        self.approve_button = ttk.Button(toolbar, text="Approve", style="Accent.TButton", command=self.approve_current)
        self.approve_button.grid(row=0, column=7)

        ttk.Label(viewer_card, textvariable=self.shortcuts_var, style="MutedCard.TLabel").grid(
            row=2, column=0, sticky="w", pady=(10, 0)
        )

        sidebar = ttk.Frame(content, style="Card.TFrame", padding=(14, 14, 14, 14))
        sidebar.grid(row=0, column=1, sticky="nsew")
        sidebar.rowconfigure(6, weight=1)
        sidebar.columnconfigure(0, weight=1)

        ttk.Label(sidebar, text="Current Page", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.badge_label = tk.Label(
            sidebar,
            textvariable=self.badge_var,
            bg="#eef2ff",
            fg=ACCENT,
            font=("TkDefaultFont", 10, "bold"),
            padx=10,
            pady=4,
        )
        self.badge_label.grid(row=1, column=0, sticky="w", pady=(8, 10))

        ttk.Label(sidebar, textvariable=self.chapter_var, style="StrongCard.TLabel", wraplength=360).grid(row=2, column=0, sticky="w")
        ttk.Label(sidebar, textvariable=self.page_var, style="CardBody.TLabel", wraplength=360).grid(row=3, column=0, sticky="w", pady=(6, 0))
        ttk.Label(sidebar, textvariable=self.box_var, style="MutedCard.TLabel", wraplength=360).grid(row=4, column=0, sticky="w", pady=(6, 0))
        ttk.Label(sidebar, textvariable=self.help_var, style="CardBody.TLabel", wraplength=360, justify=tk.LEFT).grid(
            row=5, column=0, sticky="ew", pady=(14, 12)
        )

        preview_frame = ttk.Frame(sidebar, style="CardInner.TFrame")
        preview_frame.grid(row=6, column=0, sticky="nsew")
        preview_frame.rowconfigure(1, weight=1)
        preview_frame.columnconfigure(0, weight=1)

        ttk.Label(preview_frame, text="Crop Preview", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))
        self.crop_preview_canvas = tk.Canvas(preview_frame, background=PREVIEW_BG, highlightthickness=0, height=360)
        self.crop_preview_canvas.grid(row=1, column=0, sticky="nsew")
        ttk.Label(preview_frame, textvariable=self.crop_preview_var, style="MutedCard.TLabel", wraplength=360).grid(
            row=2, column=0, sticky="w", pady=(10, 0)
        )

    def _bind_events(self) -> None:
        self.root.bind("<Return>", lambda _event: self.approve_current())
        self.root.bind("e", lambda _event: self.enable_edit_mode())
        self.root.bind("u", lambda _event: self.unapprove_current())
        self.root.bind("r", lambda _event: self.reset_to_suggestion())
        self.root.bind("b", lambda _event: self.open_browser_window())
        self.root.bind("<Escape>", lambda _event: self.cancel_edit())
        self.root.bind("<Left>", lambda _event: self.go_previous())
        self.root.bind("<Right>", lambda _event: self.go_next())
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.canvas.bind("<ButtonPress-1>", self._on_mouse_down)
        self.canvas.bind("<B1-Motion>", self._on_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_mouse_up)
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.crop_preview_canvas.bind("<Configure>", self._on_preview_resize)

    def close(self) -> None:
        if not self._can_leave_current_page(on_close=True):
            return

        if self.browser_window is not None:
            self.browser_window.close()
            self.browser_window = None

        if self.current_image is not None:
            self.current_image.close()
            self.current_image = None

        self.root.destroy()

    def _load_pages(self) -> list[ReviewPage]:
        pages: list[ReviewPage] = []
        for chapter in self.manifest.get("chapters", []):
            state_path = Path(chapter["state_path"]).resolve()
            state = load_chapter_crop_state(state_path.parent)
            state_pages = state.get("pages", {})
            for page_name in sorted(state_pages.keys()):
                entry = state_pages[page_name]
                suggested_box = deserialize_box(entry.get("suggested_box"))
                if suggested_box is None:
                    continue

                image_size = entry.get("image_size") or [0, 0]
                try:
                    image_width = int(image_size[0])
                    image_height = int(image_size[1])
                except (IndexError, TypeError, ValueError):
                    image_width = 0
                    image_height = 0

                pages.append(
                    ReviewPage(
                        chapter_id=chapter["chapter_id"],
                        chapter_title=chapter["chapter_title"],
                        state_path=state_path,
                        page_name=page_name,
                        page_path=Path(entry["page_path"]).resolve(),
                        cropped_path=Path(entry["cropped_path"]).resolve(),
                        image_width=image_width,
                        image_height=image_height,
                        suggested_box=suggested_box,
                        approved_box=deserialize_box(entry.get("approved_box")),
                        status=str(entry.get("status") or "pending"),
                    )
                )
        return pages

    def _initial_index(self) -> int:
        for idx, page in enumerate(self.pages):
            if not self._is_page_approved(page):
                return idx
        return 0

    def _approved_count(self) -> int:
        return sum(1 for page in self.pages if self._is_page_approved(page))

    def _pending_count(self) -> int:
        return len(self.pages) - self._approved_count()

    def _is_page_approved(self, page: ReviewPage) -> bool:
        return page.status == "approved" and page.approved_box is not None

    def _persisted_box_for_page(self, page: ReviewPage) -> BBox:
        return page.approved_box or page.suggested_box

    def preview_box_for_index(self, index: int) -> BBox:
        page = self.pages[index]
        if index == self.current_index and self.current_box is not None:
            return self.current_box
        return self._persisted_box_for_page(page)

    def open_browser_window(self) -> None:
        if self.browser_window is not None and self.browser_window.exists:
            self.browser_window.focus()
            self.browser_window.sync_from_app(select_current=True)
            return

        self.browser_window = PageBrowserWindow(self)
        self.browser_window.sync_from_app(select_current=True)

    def _notify_browser(self, select_current: bool = False) -> None:
        if self.browser_window is not None and self.browser_window.exists:
            self.browser_window.sync_from_app(select_current=select_current)

    def _set_default_help(self) -> None:
        if self.page_dirty:
            self.help_var.set(
                "You have an unapproved change on this page. Click Approve to save it, Unapprove to clear the saved crop, or Reset to Suggestion to go back."
            )
            return

        self.help_var.set(
            "Approve keeps the current crop. Unapprove clears a saved crop. Edit lets you redraw the crop box. Use Back or the Page Browser to revisit anything."
        )

    def _set_badge(self, *, approved: bool, dirty: bool, edit_mode: bool) -> None:
        if edit_mode:
            self.badge_var.set("EDIT MODE")
            self.badge_label.configure(bg="#fff7ed", fg=WARNING)
            return

        if dirty:
            self.badge_var.set("UNSAVED CHANGE")
            self.badge_label.configure(bg="#fff7ed", fg=WARNING)
            return

        if approved:
            self.badge_var.set("APPROVED")
            self.badge_label.configure(bg="#ecfdf5", fg=SUCCESS_DARK)
            return

        self.badge_var.set("PENDING")
        self.badge_label.configure(bg="#eef2ff", fg=ACCENT)

    def _on_canvas_resize(self, _event: tk.Event[tk.Misc]) -> None:
        if self.current_image is not None:
            self._render_current_page()

    def _on_preview_resize(self, _event: tk.Event[tk.Misc]) -> None:
        self._render_crop_preview()

    def _show_current_page(self) -> None:
        page = self.pages[self.current_index]

        if self.current_image is not None:
            self.current_image.close()
        self.current_image = Image.open(page.page_path)
        self.cached_display_size = None
        self.tk_image = None
        self.current_box = self._persisted_box_for_page(page)
        self.previous_box_before_edit = self.current_box
        self.edit_mode = False
        self.drag_start = None
        self.page_dirty = False
        self._set_default_help()
        self._render_current_page()
        self._notify_browser(select_current=True)

    def _render_current_page(self) -> None:
        if self.current_image is None:
            return

        canvas_width = max(1, self.canvas.winfo_width())
        canvas_height = max(1, self.canvas.winfo_height())
        image_width, image_height = self.current_image.size

        scale = min(canvas_width / image_width, canvas_height / image_height)
        scale = max(0.05, min(scale, 1.0))
        self.scale = scale

        display_width = max(1, int(round(image_width * scale)))
        display_height = max(1, int(round(image_height * scale)))
        self.offset_x = max(0, (canvas_width - display_width) // 2)
        self.offset_y = max(0, (canvas_height - display_height) // 2)

        if self.tk_image is None or self.cached_display_size != (display_width, display_height):
            display_image = self.current_image.resize((display_width, display_height), RESAMPLE_LANCZOS)
            self.tk_image = ImageTk.PhotoImage(display_image)
            self.cached_display_size = (display_width, display_height)

        self.canvas.delete("all")
        self.canvas.create_image(self.offset_x, self.offset_y, anchor=tk.NW, image=self.tk_image)

        page_left = self.offset_x
        page_top = self.offset_y
        page_right = self.offset_x + display_width
        page_bottom = self.offset_y + display_height

        if self.current_box is not None:
            x1, y1, x2, y2 = self._box_to_canvas(self.current_box)
            shade_style = {"fill": "#000000", "stipple": "gray50", "outline": ""}
            self.canvas.create_rectangle(page_left, page_top, page_right, y1, **shade_style)
            self.canvas.create_rectangle(page_left, y2, page_right, page_bottom, **shade_style)
            self.canvas.create_rectangle(page_left, y1, x1, y2, **shade_style)
            self.canvas.create_rectangle(x2, y1, page_right, y2, **shade_style)

            outline = OUTLINE_EDIT if self.edit_mode else (OUTLINE_APPROVED if self._is_page_approved(self.pages[self.current_index]) and not self.page_dirty else OUTLINE_PENDING)
            self.canvas.create_rectangle(x1, y1, x2, y2, outline=outline, width=3)
            handle_size = 6
            for handle_x, handle_y in ((x1, y1), (x2, y1), (x1, y2), (x2, y2)):
                self.canvas.create_rectangle(
                    handle_x - handle_size,
                    handle_y - handle_size,
                    handle_x + handle_size,
                    handle_y + handle_size,
                    fill=outline,
                    outline="#ffffff",
                    width=1,
                )

        if self.edit_mode:
            self.canvas.create_text(
                self.offset_x + 18,
                self.offset_y + 18,
                anchor=tk.NW,
                text="Edit mode: drag a new crop box",
                fill="#f8fafc",
                font=("TkDefaultFont", 12, "bold"),
            )

        self._update_sidebar()
        self._update_progress()
        self._render_crop_preview()

    def _update_progress(self) -> None:
        approved = self._approved_count()
        total = len(self.pages)
        pending = total - approved
        current_page_number = self.current_index + 1

        self.progress_var.set(f"{approved}/{total} pages approved")
        self.status_var.set(f"{pending} pending  •  viewing page {current_page_number} of {total}")
        self.progress_bar.configure(value=(approved / max(total, 1)) * 100.0)

    def _update_sidebar(self) -> None:
        page = self.pages[self.current_index]
        box = self.current_box or self._persisted_box_for_page(page)
        box_width, box_height = _box_size(box)
        source_name = "Approved crop" if page.approved_box is not None and not self.page_dirty else "Suggested crop"
        if self.page_dirty:
            source_name = "Unsaved crop"

        self.chapter_var.set(f"{page.chapter_title}  ({page.chapter_id})")
        self.page_var.set(f"{page.page_name}  •  {page.image_width} × {page.image_height}px")
        self.box_var.set(f"{source_name}: {box_width} × {box_height}px  •  box {box}")
        self._set_badge(approved=self._is_page_approved(page), dirty=self.page_dirty, edit_mode=self.edit_mode)
        self._update_navigation_buttons()

    def _update_navigation_buttons(self) -> None:
        state_prev = tk.NORMAL if self.current_index > 0 else tk.DISABLED
        state_next = tk.NORMAL if self.current_index < len(self.pages) - 1 else tk.DISABLED
        state_unapprove = tk.NORMAL if self.pages[self.current_index].approved_box is not None else tk.DISABLED
        self.back_button.configure(state=state_prev)
        self.next_button.configure(state=state_next)
        self.unapprove_button.configure(state=state_unapprove)

    def _render_crop_preview(self) -> None:
        self.crop_preview_canvas.delete("all")
        self.crop_preview_image = None

        if self.current_image is None or self.current_box is None:
            self.crop_preview_canvas.create_text(
                max(20, self.crop_preview_canvas.winfo_width() // 2),
                max(20, self.crop_preview_canvas.winfo_height() // 2),
                text="No crop preview available",
                fill="#cbd5e1",
            )
            self.crop_preview_var.set("")
            return

        crop = self.current_image.crop(self.current_box)
        canvas_width = max(1, self.crop_preview_canvas.winfo_width())
        canvas_height = max(1, self.crop_preview_canvas.winfo_height())
        preview = _resize_copy(crop, max(1, canvas_width - 20), max(1, canvas_height - 20))
        self.crop_preview_image = ImageTk.PhotoImage(preview)
        x = max(0, (canvas_width - preview.width) // 2)
        y = max(0, (canvas_height - preview.height) // 2)
        self.crop_preview_canvas.create_image(x, y, anchor=tk.NW, image=self.crop_preview_image)

        page = self.pages[self.current_index]
        source_name = "approved crop" if page.approved_box is not None and not self.page_dirty else "suggested crop"
        if self.page_dirty:
            source_name = "unsaved crop"
        self.crop_preview_var.set(f"Live preview of the {source_name}. Use Edit to redraw or Reset to Suggestion to revert.")

    def _box_to_canvas(self, box: BBox) -> BBox:
        x1, y1, x2, y2 = box
        return (
            int(round(self.offset_x + x1 * self.scale)),
            int(round(self.offset_y + y1 * self.scale)),
            int(round(self.offset_x + x2 * self.scale)),
            int(round(self.offset_y + y2 * self.scale)),
        )

    def _canvas_point_to_image_point(self, x: int, y: int) -> tuple[int, int]:
        if self.current_image is None:
            return (0, 0)

        image_width, image_height = self.current_image.size
        image_x = int(round((x - self.offset_x) / max(self.scale, 1e-6)))
        image_y = int(round((y - self.offset_y) / max(self.scale, 1e-6)))
        image_x = max(0, min(image_x, image_width))
        image_y = max(0, min(image_y, image_height))
        return (image_x, image_y)

    def _normalized_box(self, start: tuple[int, int], end: tuple[int, int]) -> BBox:
        x1 = min(start[0], end[0])
        y1 = min(start[1], end[1])
        x2 = max(start[0], end[0])
        y2 = max(start[1], end[1])
        return (x1, y1, x2, y2)

    def _recompute_dirty(self) -> None:
        page = self.pages[self.current_index]
        persisted = self._persisted_box_for_page(page)
        self.page_dirty = self.current_box is not None and self.current_box != persisted
        self._set_default_help()

    def enable_edit_mode(self) -> None:
        self.edit_mode = True
        self.drag_start = None
        self.previous_box_before_edit = self.current_box
        self.help_var.set("Edit mode is on. Drag a new crop box across the page, then click Approve to save it.")
        self._render_current_page()

    def cancel_edit(self) -> None:
        if not self.edit_mode:
            return
        self.edit_mode = False
        self.drag_start = None
        self.current_box = self.previous_box_before_edit
        self._recompute_dirty()
        self._render_current_page()

    def reset_to_suggestion(self) -> None:
        page = self.pages[self.current_index]
        self.edit_mode = False
        self.drag_start = None
        self.current_box = page.suggested_box
        self.previous_box_before_edit = self.current_box
        self._recompute_dirty()
        self._render_current_page()

    def _on_mouse_down(self, event: tk.Event[tk.Misc]) -> None:
        if not self.edit_mode:
            return
        self.drag_start = self._canvas_point_to_image_point(event.x, event.y)
        x, y = self.drag_start
        self.current_box = (x, y, x, y)
        self._render_current_page()

    def _on_mouse_drag(self, event: tk.Event[tk.Misc]) -> None:
        if not self.edit_mode or self.drag_start is None:
            return
        current = self._canvas_point_to_image_point(event.x, event.y)
        self.current_box = self._normalized_box(self.drag_start, current)
        self._render_current_page()

    def _on_mouse_up(self, event: tk.Event[tk.Misc]) -> None:
        if not self.edit_mode or self.drag_start is None:
            return
        current = self._canvas_point_to_image_point(event.x, event.y)
        candidate = self._normalized_box(self.drag_start, current)
        self.drag_start = None

        if candidate[2] - candidate[0] < 10 or candidate[3] - candidate[1] < 10:
            self.current_box = self.previous_box_before_edit
            self.edit_mode = False
            self.help_var.set("That box was too small. Click Edit and drag a larger crop box.")
            self._recompute_dirty()
            self._render_current_page()
            return

        self.current_box = candidate
        self.previous_box_before_edit = candidate
        self.edit_mode = False
        self._recompute_dirty()
        if self.page_dirty:
            self.help_var.set("New crop drawn. Click Approve to save it or Edit again to redraw.")
        self._render_current_page()
        self._notify_browser(select_current=False)

    def _can_leave_current_page(self, *, on_close: bool = False) -> bool:
        if not self.page_dirty:
            return True

        message = (
            "This page has an unapproved crop change. Close the app and discard it?"
            if on_close
            else "This page has an unapproved crop change. Leave this page and discard it?"
        )
        return messagebox.askyesno("Discard unapproved change?", message)

    def _navigate_to(self, index: int) -> None:
        if index < 0 or index >= len(self.pages) or index == self.current_index:
            return
        if not self._can_leave_current_page():
            return
        self.current_index = index
        self._show_current_page()

    def jump_to_page(self, index: int) -> None:
        self._navigate_to(index)

    def go_previous(self) -> None:
        self._navigate_to(self.current_index - 1)

    def go_next(self) -> None:
        self._navigate_to(self.current_index + 1)

    def approve_current(self) -> None:
        page = self.pages[self.current_index]
        box = self.current_box or page.approved_box or page.suggested_box
        self._save_page_approval(page, box)

        page.approved_box = box
        page.status = "approved"
        self.pages[self.current_index] = page
        self.page_dirty = False
        self.edit_mode = False
        self.current_box = box
        self.previous_box_before_edit = box
        self._set_default_help()
        self._notify_browser(select_current=False)

        if self.current_index < len(self.pages) - 1:
            self.current_index += 1
            self._show_current_page()
        else:
            self._render_current_page()
            self._finish_review()

    def unapprove_current(self) -> None:
        page = self.pages[self.current_index]
        self._clear_page_approval(page)

        page.approved_box = None
        page.status = "pending"
        self.pages[self.current_index] = page
        self.page_dirty = False
        self.edit_mode = False
        self.current_box = page.suggested_box
        self.previous_box_before_edit = self.current_box
        self.help_var.set("This page is now pending again. Edit it or approve it when you are ready.")
        self._notify_browser(select_current=False)
        self._render_current_page()

    def _save_page_approval(self, page: ReviewPage, box: BBox) -> None:
        state = load_chapter_crop_state(page.state_path.parent)
        pages = state.setdefault("pages", {})
        entry = pages.get(page.page_name)
        if not isinstance(entry, dict):
            raise RuntimeError(f"Crop state is missing page entry for {page.page_name} in {page.state_path}")

        entry["approved_box"] = [int(box[0]), int(box[1]), int(box[2]), int(box[3])]
        entry["status"] = "approved"
        pages[page.page_name] = entry
        save_chapter_crop_state(page.state_path.parent, state)

        page.cropped_path.parent.mkdir(parents=True, exist_ok=True)
        image = Image.open(page.page_path)
        try:
            cropped = image.crop(box)
            cropped.save(page.cropped_path)
            cropped.close()
        finally:
            image.close()

    def _clear_page_approval(self, page: ReviewPage) -> None:
        state = load_chapter_crop_state(page.state_path.parent)
        pages = state.setdefault("pages", {})
        entry = pages.get(page.page_name)
        if not isinstance(entry, dict):
            raise RuntimeError(f"Crop state is missing page entry for {page.page_name} in {page.state_path}")

        entry["approved_box"] = None
        entry["status"] = "pending"
        pages[page.page_name] = entry
        save_chapter_crop_state(page.state_path.parent, state)

        if page.cropped_path.exists():
            page.cropped_path.unlink()

    def _finish_review(self) -> None:
        if self._approved_count() == len(self.pages):
            self.help_var.set(
                "Everything is approved. You can still browse pages or make adjustments, or close the app and run build when ready."
            )
            if not self.all_done_notified:
                self.all_done_notified = True
                messagebox.showinfo(
                    "Crop Review",
                    "All pages are approved. You can now run the build command and it will reuse these reviewed crops.",
                )
        else:
            self._set_default_help()


class PageBrowserWindow:
    def __init__(self, app: CropReviewApp) -> None:
        self.app = app
        self.exists = True
        self.preview_index: int | None = None
        self.original_photo: ImageTk.PhotoImage | None = None
        self.cropped_photo: ImageTk.PhotoImage | None = None
        self.preview_info_var = tk.StringVar(value="")
        self.preview_note_var = tk.StringVar(value="Pending pages use their suggested crop in the cropped preview tab.")
        self.filter_var = tk.StringVar(value="All Pages")

        self.window = tk.Toplevel(app.root)
        self.window.title("Page Browser")
        self.window.geometry("1360x860")
        self.window.minsize(1040, 720)
        self.window.configure(background=BG)
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        self.window.bind("<Escape>", lambda _event: self.close())

        self._build_layout()

    def focus(self) -> None:
        self.window.deiconify()
        self.window.lift()
        self.window.focus_force()

    def close(self) -> None:
        if not self.exists:
            return
        self.exists = False
        self.window.destroy()
        if self.app.browser_window is self:
            self.app.browser_window = None

    def _build_layout(self) -> None:
        self.window.rowconfigure(0, weight=1)
        self.window.columnconfigure(0, weight=1)

        main = ttk.Frame(self.window, style="App.TFrame", padding=(16, 16, 16, 16))
        main.grid(row=0, column=0, sticky="nsew")
        main.rowconfigure(2, weight=1)
        main.columnconfigure(0, weight=1)

        header = ttk.Frame(main, style="App.TFrame")
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text="Page Browser", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            header,
            text="Jump anywhere in the book. The uncropped tab shows the original page with the crop box overlaid.",
            style="Subtitle.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(2, 0))

        controls = ttk.Frame(main, style="Card.TFrame", padding=(14, 12, 14, 12))
        controls.grid(row=1, column=0, sticky="ew", pady=(14, 14))
        controls.columnconfigure(5, weight=1)

        ttk.Label(controls, text="Show", style="CardBody.TLabel").grid(row=0, column=0, sticky="w")
        self.filter_box = ttk.Combobox(
            controls,
            textvariable=self.filter_var,
            values=("All Pages", "Pending Only", "Approved Only"),
            state="readonly",
            width=16,
        )
        self.filter_box.grid(row=0, column=1, sticky="w", padx=(8, 14))
        self.filter_box.bind("<<ComboboxSelected>>", lambda _event: self.refresh_page_list(select_index=self.preview_index))

        ttk.Button(controls, text="Jump to Current", style="Secondary.TButton", command=self._jump_to_current).grid(
            row=0, column=2, padx=(0, 8)
        )
        ttk.Button(controls, text="Open Selected", style="Accent.TButton", command=self._open_selected).grid(
            row=0, column=3, padx=(0, 8)
        )
        ttk.Button(controls, text="Refresh", style="Ghost.TButton", command=lambda: self.sync_from_app(select_current=False)).grid(
            row=0, column=4, padx=(0, 8)
        )
        ttk.Button(controls, text="Close", style="Ghost.TButton", command=self.close).grid(row=0, column=6, sticky="e")

        content = ttk.Frame(main, style="App.TFrame")
        content.grid(row=2, column=0, sticky="nsew")
        content.rowconfigure(0, weight=1)
        content.columnconfigure(0, weight=3)
        content.columnconfigure(1, weight=5)

        list_card = ttk.Frame(content, style="Card.TFrame", padding=(12, 12, 12, 12))
        list_card.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        list_card.rowconfigure(1, weight=1)
        list_card.columnconfigure(0, weight=1)

        ttk.Label(list_card, text="Pages", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))

        tree_frame = ttk.Frame(list_card, style="CardInner.TFrame")
        tree_frame.grid(row=1, column=0, sticky="nsew")
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        self.tree = ttk.Treeview(tree_frame, columns=("status", "chapter", "page"), show="headings", selectmode="browse")
        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.heading("status", text="Status")
        self.tree.heading("chapter", text="Chapter")
        self.tree.heading("page", text="Page")
        self.tree.column("status", width=110, anchor=tk.W, stretch=False)
        self.tree.column("chapter", width=210, anchor=tk.W, stretch=True)
        self.tree.column("page", width=180, anchor=tk.W, stretch=True)
        self.tree.tag_configure("approved", foreground=SUCCESS_DARK)
        self.tree.tag_configure("pending", foreground=ACCENT)
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)
        self.tree.bind("<Double-1>", lambda _event: self._open_selected())

        preview_card = ttk.Frame(content, style="Card.TFrame", padding=(12, 12, 12, 12))
        preview_card.grid(row=0, column=1, sticky="nsew")
        preview_card.rowconfigure(1, weight=1)
        preview_card.columnconfigure(0, weight=1)

        ttk.Label(preview_card, text="Selected Page Preview", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))

        notebook = ttk.Notebook(preview_card)
        notebook.grid(row=1, column=0, sticky="nsew")

        original_tab = ttk.Frame(notebook, style="CardInner.TFrame")
        cropped_tab = ttk.Frame(notebook, style="CardInner.TFrame")
        original_tab.rowconfigure(0, weight=1)
        original_tab.columnconfigure(0, weight=1)
        cropped_tab.rowconfigure(0, weight=1)
        cropped_tab.columnconfigure(0, weight=1)

        self.original_canvas = tk.Canvas(original_tab, background=CANVAS_BG, highlightthickness=0)
        self.original_canvas.grid(row=0, column=0, sticky="nsew")
        self.cropped_canvas = tk.Canvas(cropped_tab, background=PREVIEW_BG, highlightthickness=0)
        self.cropped_canvas.grid(row=0, column=0, sticky="nsew")
        self.original_canvas.bind("<Configure>", lambda _event: self._render_previews())
        self.cropped_canvas.bind("<Configure>", lambda _event: self._render_previews())

        notebook.add(original_tab, text="Uncropped")
        notebook.add(cropped_tab, text="Cropped")

        ttk.Label(preview_card, textvariable=self.preview_info_var, style="CardBody.TLabel", wraplength=680).grid(
            row=2, column=0, sticky="w", pady=(10, 4)
        )
        ttk.Label(preview_card, textvariable=self.preview_note_var, style="MutedCard.TLabel", wraplength=680).grid(
            row=3, column=0, sticky="w"
        )

    def sync_from_app(self, *, select_current: bool) -> None:
        if not self.exists:
            return
        selection = self.app.current_index if select_current else self.preview_index
        self.refresh_page_list(select_index=selection)

    def refresh_page_list(self, select_index: int | None) -> None:
        if not self.exists:
            return

        existing_selection = self._selected_page_index()
        target = select_index if select_index is not None else existing_selection

        for item in self.tree.get_children():
            self.tree.delete(item)

        visible_indices: list[int] = []
        for index, page in enumerate(self.app.pages):
            if not self._matches_filter(page):
                continue
            visible_indices.append(index)
            approved = self.app._is_page_approved(page)
            self.tree.insert(
                "",
                tk.END,
                iid=str(index),
                values=("Approved" if approved else "Pending", page.chapter_title, page.page_name),
                tags=("approved" if approved else "pending",),
            )

        if not visible_indices:
            self.preview_index = None
            self.tree.selection_remove(self.tree.selection())
            self._render_previews()
            return

        if target is None or str(target) not in self.tree.get_children():
            target = visible_indices[0]

        self.tree.selection_set(str(target))
        self.tree.see(str(target))
        self.preview_index = target
        self._render_previews()

    def _selected_page_index(self) -> int | None:
        selection = self.tree.selection()
        if not selection:
            return None
        try:
            return int(selection[0])
        except ValueError:
            return None

    def _matches_filter(self, page: ReviewPage) -> bool:
        value = self.filter_var.get()
        approved = self.app._is_page_approved(page)
        if value == "Pending Only":
            return not approved
        if value == "Approved Only":
            return approved
        return True

    def _on_tree_select(self, _event: tk.Event[tk.Misc]) -> None:
        self.preview_index = self._selected_page_index()
        self._render_previews()

    def _jump_to_current(self) -> None:
        self.refresh_page_list(select_index=self.app.current_index)

    def _open_selected(self) -> None:
        index = self._selected_page_index()
        if index is None:
            return
        self.app.jump_to_page(index)
        if self.exists:
            self.refresh_page_list(select_index=index)

    def _render_previews(self) -> None:
        self.original_canvas.delete("all")
        self.cropped_canvas.delete("all")
        self.original_photo = None
        self.cropped_photo = None

        if self.preview_index is None:
            self._render_placeholder(self.original_canvas, "No page selected")
            self._render_placeholder(self.cropped_canvas, "No cropped preview")
            self.preview_info_var.set("")
            return

        page = self.app.pages[self.preview_index]
        box = self.app.preview_box_for_index(self.preview_index)
        source_name = "approved crop" if page.approved_box is not None else "suggested crop"
        if self.preview_index == self.app.current_index and self.app.page_dirty:
            source_name = "unsaved crop"

        image = Image.open(page.page_path)
        try:
            original_preview = image.convert("RGB")
            outline_width = max(2, original_preview.width // 350)
            draw = ImageDraw.Draw(original_preview)
            outline = OUTLINE_APPROVED if page.approved_box is not None else OUTLINE_PENDING
            if self.preview_index == self.app.current_index and self.app.page_dirty:
                outline = OUTLINE_EDIT
            draw.rectangle(box, outline=outline, width=outline_width)

            cropped_preview = image.crop(box).convert("RGB")
        finally:
            image.close()

        self._render_image(self.original_canvas, original_preview, attr_name="original_photo")
        self._render_image(self.cropped_canvas, cropped_preview, attr_name="cropped_photo")

        box_width, box_height = _box_size(box)
        self.preview_info_var.set(
            f"{page.chapter_title}  •  {page.page_name}  •  {source_name}  •  {box_width} × {box_height}px"
        )

    def _render_placeholder(self, canvas: tk.Canvas, text: str) -> None:
        width = max(1, canvas.winfo_width())
        height = max(1, canvas.winfo_height())
        canvas.create_text(width // 2, height // 2, text=text, fill="#cbd5e1", font=("TkDefaultFont", 12, "bold"))

    def _render_image(self, canvas: tk.Canvas, image: Image.Image, *, attr_name: str) -> None:
        canvas_width = max(1, canvas.winfo_width())
        canvas_height = max(1, canvas.winfo_height())
        preview = _resize_copy(image, max(1, canvas_width - 20), max(1, canvas_height - 20))
        photo = ImageTk.PhotoImage(preview)
        setattr(self, attr_name, photo)
        x = max(0, (canvas_width - preview.width) // 2)
        y = max(0, (canvas_height - preview.height) // 2)
        canvas.create_image(x, y, anchor=tk.NW, image=photo)
