from __future__ import annotations

import datetime as dt
import zipfile
from html import escape
from pathlib import Path

from .xhtml import DEFAULT_CSS, nav_xhtml, toc_ncx


CONTAINER_XML = """<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\">
  <rootfiles>
    <rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/>
  </rootfiles>
</container>
"""


def _content_opf(
    title: str,
    author: str,
    language: str,
    identifier: str,
    chapter_files: list[tuple[str, str]],
) -> str:
    modified = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    manifest_items = [
        '    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>',
        '    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>',
        '    <item id="css" href="styles/book.css" media-type="text/css"/>',
    ]
    spine_items = []
    for idx, (filename, _) in enumerate(chapter_files, start=1):
        manifest_items.append(
            f'    <item id="chap{idx}" href="Text/{escape(filename)}" media-type="application/xhtml+xml"/>'
        )
        spine_items.append(f'    <itemref idref="chap{idx}"/>')

    manifest = "\n".join(manifest_items)
    spine = "\n".join(spine_items)

    return f"""<?xml version=\"1.0\" encoding=\"utf-8\"?>
<package version=\"3.0\" unique-identifier=\"bookid\" xmlns=\"http://www.idpf.org/2007/opf\">
  <metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\">
    <dc:identifier id=\"bookid\">{escape(identifier)}</dc:identifier>
    <dc:title>{escape(title)}</dc:title>
    <dc:creator>{escape(author)}</dc:creator>
    <dc:language>{escape(language)}</dc:language>
    <meta property=\"dcterms:modified\">{modified}</meta>
  </metadata>
  <manifest>
{manifest}
  </manifest>
  <spine toc=\"ncx\">
{spine}
  </spine>
</package>
"""


def build_epub(
    output_epub: str | Path,
    title: str,
    author: str,
    language: str,
    identifier: str,
    chapters: list[tuple[str, str, str]],
) -> Path:
    output_epub = Path(output_epub)
    output_epub.parent.mkdir(parents=True, exist_ok=True)

    chapter_files = [(filename, chapter_title) for filename, chapter_title, _ in chapters]
    nav = nav_xhtml(title, chapter_files, language=language)
    ncx = toc_ncx(title, identifier, chapter_files)
    opf = _content_opf(title, author, language, identifier, chapter_files)

    with zipfile.ZipFile(output_epub, "w") as zf:
        zf.writestr(zipfile.ZipInfo("mimetype"), "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        zf.writestr("META-INF/container.xml", CONTAINER_XML)
        zf.writestr("OEBPS/content.opf", opf)
        zf.writestr("OEBPS/nav.xhtml", nav)
        zf.writestr("OEBPS/toc.ncx", ncx)
        zf.writestr("OEBPS/styles/book.css", DEFAULT_CSS)
        for filename, _, xhtml in chapters:
            zf.writestr(f"OEBPS/Text/{filename}", xhtml)

    return output_epub
