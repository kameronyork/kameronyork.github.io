from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class OCRLine:
    page_index: int
    block_num: int
    par_num: int
    line_num: int
    left: int
    top: int
    width: int
    height: int
    conf: float
    text: str

    @property
    def right(self) -> int:
        return self.left + self.width

    @property
    def bottom(self) -> int:
        return self.top + self.height


@dataclass(slots=True)
class PageOCR:
    page_index: int
    width: int
    height: int
    lines: list[OCRLine] = field(default_factory=list)


@dataclass(slots=True)
class Paragraph:
    text: str
    page_indices: list[int]
    starts_indented: bool
    first_line_left: int


@dataclass(slots=True)
class ChapterSpec:
    id: str
    title: str
    pdf: Path


@dataclass(slots=True)
class CropModelConfig:
    layout_command: str = "surya_layout"
    ocr_command: str = "surya_ocr"
    margin_px: int = 24
    min_box_area_ratio: float = 0.00035
    max_boxes: int = 140


@dataclass(slots=True)
class CleanupConfig:
    drop_regexes: list[str] = field(default_factory=list)
    detect_repeated_headers: bool = True
    detect_repeated_footers: bool = True
    indent_threshold_px: int = 28
    paragraph_gap_ratio: float = 1.6


@dataclass(slots=True)
class FullBookConfig:
    pdf: Path
    preview_dpi: int = 120


@dataclass(slots=True)
class BookConfig:
    title: str
    author: str
    language: str
    identifier: str
    render_dpi: int
    ocr_engine: str
    layout_engine: str
    work_dir: Path
    output_epub: Path
    crop_model: CropModelConfig
    cleanup: CleanupConfig
    chapters: list[ChapterSpec]
    full_book: FullBookConfig | None = None
