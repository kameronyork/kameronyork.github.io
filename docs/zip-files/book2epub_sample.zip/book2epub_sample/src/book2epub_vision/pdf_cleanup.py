from __future__ import annotations

import shutil
from itertools import count
from pathlib import Path

import fitz


class PDFCleanupError(RuntimeError):
    pass


def _next_backup_path(pdf_path: Path) -> Path:
    first = pdf_path.with_name(f"{pdf_path.stem}.original{pdf_path.suffix}")
    if not first.exists():
        return first

    for index in count(1):
        candidate = pdf_path.with_name(f"{pdf_path.stem}.original-{index}{pdf_path.suffix}")
        if not candidate.exists():
            return candidate

    raise PDFCleanupError(f"Could not create a backup path for {pdf_path}")


def _temporary_output_path(output_pdf: Path) -> Path:
    for index in count(1):
        candidate = output_pdf.with_name(f".{output_pdf.stem}.cleanup-{index}.tmp{output_pdf.suffix}")
        if not candidate.exists():
            return candidate

    raise PDFCleanupError(f"Could not create a temporary output path for {output_pdf}")


def _verify_cleaned_pdf(pdf_path: Path, expected_page_count: int) -> None:
    try:
        doc = fitz.open(pdf_path)
    except Exception as exc:  # noqa: BLE001
        raise PDFCleanupError(f"Cleaned PDF could not be opened: {pdf_path}") from exc

    try:
        if doc.page_count != expected_page_count:
            raise PDFCleanupError(
                f"Cleaned PDF page count changed from {expected_page_count} to {doc.page_count}: {pdf_path}"
            )

        rotated_pages: list[str] = []
        invalid_pages: list[str] = []
        for page_index, page in enumerate(doc, start=1):
            if page.rotation % 360:
                rotated_pages.append(str(page_index))
            if page.rect.width <= 0 or page.rect.height <= 0:
                invalid_pages.append(str(page_index))

        if rotated_pages:
            sample = ", ".join(rotated_pages[:20])
            if len(rotated_pages) > 20:
                sample += ", ..."
            raise PDFCleanupError(f"Cleaned PDF still has rotated page metadata on pages: {sample}")

        if invalid_pages:
            sample = ", ".join(invalid_pages[:20])
            if len(invalid_pages) > 20:
                sample += ", ..."
            raise PDFCleanupError(f"Cleaned PDF has invalid page dimensions on pages: {sample}")
    finally:
        doc.close()


def clean_pdf(pdf_path: str | Path, output_pdf: str | Path | None = None) -> Path:
    """Normalize a PDF for the scanned-book pipeline.

    The cleanup removes page rotation metadata while preserving the visible page
    appearance, then rewrites the file with PyMuPDF garbage collection and stream
    compression. If output_pdf is omitted, the source file is replaced after a
    backup is created next to it.
    """

    source_pdf = Path(pdf_path).expanduser().resolve()
    if not source_pdf.exists() or not source_pdf.is_file():
        raise FileNotFoundError(f"PDF does not exist: {source_pdf}")

    target_pdf = Path(output_pdf).expanduser().resolve() if output_pdf is not None else source_pdf
    target_pdf.parent.mkdir(parents=True, exist_ok=True)
    temp_pdf = _temporary_output_path(target_pdf)

    backup_pdf: Path | None = None
    doc: fitz.Document | None = None
    try:
        doc = fitz.open(source_pdf)
        if doc.needs_pass:
            raise PDFCleanupError(f"Encrypted PDFs are not supported by cleanup: {source_pdf}")

        page_count = doc.page_count
        rotations_removed = 0
        for page in doc:
            if page.rotation % 360:
                page.remove_rotation()
                rotations_removed += 1

        doc.save(
            temp_pdf,
            garbage=4,
            clean=True,
            deflate=True,
            deflate_images=True,
            deflate_fonts=True,
        )
        doc.close()
        doc = None

        _verify_cleaned_pdf(temp_pdf, expected_page_count=page_count)

        if target_pdf == source_pdf:
            backup_pdf = _next_backup_path(source_pdf)
            shutil.copy2(source_pdf, backup_pdf)

        temp_pdf.replace(target_pdf)
        if backup_pdf is not None:
            print(f"Backup saved to: {backup_pdf}")
        print(f"Cleaned PDF: {target_pdf}")
        print(f"Pages checked: {page_count}")
        print(f"Page rotations flattened: {rotations_removed}")
        return target_pdf
    except Exception:
        if temp_pdf.exists():
            temp_pdf.unlink()
        raise
    finally:
        if doc is not None:
            doc.close()


def clean_pdf_in_place(pdf_path: str | Path) -> Path:
    return clean_pdf(pdf_path, output_pdf=None)
