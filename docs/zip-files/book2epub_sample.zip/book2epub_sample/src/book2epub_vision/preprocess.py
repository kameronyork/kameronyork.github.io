from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
from tqdm import tqdm


def suppress_bleedthrough_for_ocr(image_path: Path, output_path: Path) -> Path:
    image = cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"Could not read image: {image_path}")

    # Normalize contrast a bit
    image = cv2.GaussianBlur(image, (3, 3), 0)
    image = cv2.normalize(image, None, 0, 255, cv2.NORM_MINMAX)

    # Adaptive threshold:
    # Keeps darker foreground strokes, throws away faint background bleed.
    binary = cv2.adaptiveThreshold(
        image,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        41,   # neighborhood size; odd number
        18,   # subtraction constant; larger = more aggressive background removal
    )

    # Small morphology cleanup
    kernel = np.ones((2, 2), np.uint8)
    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(output_path), binary)
    return output_path


def preprocess_chapter_images_for_ocr(
    image_paths: list[Path],
    output_dir: Path,
) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)

    processed_paths: list[Path] = []
    for image_path in tqdm(image_paths, desc="Preprocessing OCR pages", unit="page", leave=False):
        out_path = output_dir / image_path.name
        suppress_bleedthrough_for_ocr(image_path, out_path)
        processed_paths.append(out_path)

    return processed_paths