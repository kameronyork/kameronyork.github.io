from __future__ import annotations

import json
from pathlib import Path

from .models import BookConfig, ChapterSpec, CleanupConfig, CropModelConfig, FullBookConfig


def _resolve(base: Path, value: str) -> Path:
    raw = Path(value)
    return raw if raw.is_absolute() else (base / raw).resolve()


def _strip_json_comments(text: str) -> str:
    output: list[str] = []
    in_string = False
    escape = False
    index = 0

    while index < len(text):
        char = text[index]

        if in_string:
            output.append(char)
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
            index += 1
            continue

        if char == '"':
            in_string = True
            output.append(char)
            index += 1
            continue

        if char == "/" and index + 1 < len(text):
            next_char = text[index + 1]
            if next_char == "/":
                index += 2
                while index < len(text) and text[index] not in "\r\n":
                    index += 1
                continue
            if next_char == "*":
                index += 2
                while index + 1 < len(text) and not (text[index] == "*" and text[index + 1] == "/"):
                    index += 1
                index = min(index + 2, len(text))
                continue

        output.append(char)
        index += 1

    return "".join(output)


def _load_full_book_config(base_dir: Path, raw: dict[str, object], default_render_dpi: int) -> FullBookConfig | None:
    value = raw.get("full_book")
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError("The 'full_book' config entry must be an object.")

    pdf_value = value.get("pdf")
    if not isinstance(pdf_value, str) or not pdf_value.strip():
        raise ValueError("The 'full_book.pdf' config entry is required when 'full_book' is present.")

    preview_dpi = int(value.get("preview_dpi", value.get("render_dpi", 120)))
    return FullBookConfig(
        pdf=_resolve(base_dir, pdf_value),
        preview_dpi=preview_dpi,
    )


def load_config(config_path: str | Path) -> BookConfig:
    path = Path(config_path).resolve()
    raw_text = path.read_text(encoding="utf-8")
    raw = json.loads(_strip_json_comments(raw_text))

    render_dpi = int(raw.get("render_dpi", 300))

    chapters = [
        ChapterSpec(
            id=item["id"],
            title=item["title"],
            pdf=_resolve(path.parent, item["pdf"]),
        )
        for item in raw["chapters"]
    ]

    return BookConfig(
        title=raw["title"],
        author=raw["author"],
        language=raw.get("language", "en"),
        identifier=raw["identifier"],
        render_dpi=render_dpi,
        ocr_engine=raw.get("ocr_engine", "surya"),
        layout_engine=raw.get("layout_engine", "surya"),
        work_dir=_resolve(path.parent, raw["work_dir"]),
        output_epub=_resolve(path.parent, raw["output_epub"]),
        crop_model=CropModelConfig(**raw.get("crop_model", {})),
        cleanup=CleanupConfig(**raw.get("cleanup", {})),
        chapters=chapters,
        full_book=_load_full_book_config(path.parent, raw, default_render_dpi=render_dpi),
    )
