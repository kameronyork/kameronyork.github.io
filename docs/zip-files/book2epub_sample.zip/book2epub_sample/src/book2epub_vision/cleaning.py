from __future__ import annotations

import html
import re
import statistics
from collections import Counter

from tqdm import tqdm

from .models import CleanupConfig, OCRLine, PageOCR, Paragraph


TERMINAL_PUNCTUATION = tuple('.!?"\'”’)')
_INLINE_TAG_RE = re.compile(r"</?(?:i|em|b|strong|sub|sup|br\s*/?)>", flags=re.IGNORECASE)


def _latinish_ratio(text: str) -> float:
    chars = [ch for ch in text if ch.isalpha()]
    if not chars:
        return 1.0
    latin = sum(("A" <= ch <= "Z") or ("a" <= ch <= "z") or ("\u00C0" <= ch <= "\u024F") for ch in chars)
    return latin / len(chars)


def _contains_cjk(text: str) -> bool:
    for ch in text:
        code = ord(ch)
        if (
            0x4E00 <= code <= 0x9FFF or
            0x3400 <= code <= 0x4DBF or
            0x3040 <= code <= 0x309F or
            0x30A0 <= code <= 0x30FF or
            0xAC00 <= code <= 0xD7AF
        ):
            return True
    return False


def _normalize_running_text(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"\d+", "", text)
    text = re.sub(r"[^a-z]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _strip_unknown_tags(text: str) -> str:
    return re.sub(
        r"</?(?!i\b|em\b|b\b|strong\b|sub\b|sup\b|br\b)[a-zA-Z0-9:_-][^>]*>",
        "",
        text,
    )


def _normalize_ocr_markup(text: str) -> str:
    text = html.unescape(text)

    text = re.sub(r"<math[^>]*>(.*?)</math>", r"\1", text, flags=re.IGNORECASE | re.DOTALL)

    text = re.sub(r"<\s*i\s*>", "<i>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*/\s*i\s*>", "</i>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*em\s*>", "<em>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*/\s*em\s*>", "</em>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*b\s*>", "<b>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*/\s*b\s*>", "</b>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*strong\s*>", "<strong>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*/\s*strong\s*>", "</strong>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*sub\s*>", "<sub>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*/\s*sub\s*>", "</sub>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*sup\s*>", "<sup>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*/\s*sup\s*>", "</sup>", text, flags=re.IGNORECASE)
    text = re.sub(r"<\s*br\s*/?\s*>", "<br/>", text, flags=re.IGNORECASE)

    text = _strip_unknown_tags(text)

    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+(</?(?:i|em|b|strong|sub|sup)>)", r"\1", text, flags=re.IGNORECASE)
    text = re.sub(r"(<(?:i|em|b|strong|sub|sup)>)\s+", r"\1", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*(<br/>)\s*", r"\1", text, flags=re.IGNORECASE)
    return text.strip()


def detect_repeated_margin_lines(pages: list[PageOCR]) -> set[str]:
    counts: Counter[str] = Counter()
    for page in pages:
        top_lines = [line for line in page.lines if line.top / max(page.height, 1) <= 0.16]
        bottom_lines = [line for line in page.lines if line.bottom / max(page.height, 1) >= 0.84]
        candidates = top_lines[:2] + bottom_lines[-2:]
        for line in candidates:
            normalized = _normalize_running_text(line.text)
            if 2 <= len(normalized) <= 60:
                counts[normalized] += 1
    minimum_hits = max(2, round(len(pages) * 0.3))
    return {text for text, count in counts.items() if count >= minimum_hits}


def _compile_drop_patterns(config: CleanupConfig) -> list[re.Pattern[str]]:
    return [re.compile(pattern, flags=re.IGNORECASE) for pattern in config.drop_regexes]


def _line_should_drop(
    line: OCRLine,
    page: PageOCR,
    repeated_margin_texts: set[str],
    drop_patterns: list[re.Pattern[str]],
    config: CleanupConfig,
) -> bool:
    text = line.text.strip()
    if not text:
        return True

    if re.fullmatch(r"[-‐-‒–—―~_=*•·.,:;!?'\"`]+", text):
        return True

    if line.conf and line.conf < 20.0 and len(text) <= 3:
        return True

    if re.fullmatch(r"[\W_]*\d+[\W_]*", text):
        return True

    if any(pattern.fullmatch(text) for pattern in drop_patterns):
        return True

    normalized = _normalize_running_text(text)
    top_ratio = line.top / max(page.height, 1)
    bottom_ratio = line.bottom / max(page.height, 1)

    if config.detect_repeated_headers and top_ratio <= 0.16 and normalized in repeated_margin_texts:
        return True
    if config.detect_repeated_footers and bottom_ratio >= 0.84 and normalized in repeated_margin_texts:
        return True

    if _contains_cjk(text) and _latinish_ratio(text) < 0.5:
        return True

    return False


def filter_page_lines(page: PageOCR, repeated_margin_texts: set[str], config: CleanupConfig) -> list[OCRLine]:
    drop_patterns = _compile_drop_patterns(config)
    kept = [
        line
        for line in page.lines
        if not _line_should_drop(
            line=line,
            page=page,
            repeated_margin_texts=repeated_margin_texts,
            drop_patterns=drop_patterns,
            config=config,
        )
    ]
    kept.sort(key=lambda line: (line.top, line.left))
    return kept


def _join_line_text(previous: str, current: str) -> str:
    previous = previous.rstrip()
    current = current.lstrip()
    if not previous:
        return current

    plain_previous = _INLINE_TAG_RE.sub("", previous)
    plain_current = _INLINE_TAG_RE.sub("", current)

    if plain_previous.endswith("-") and plain_current and plain_current[:1].islower():
        return previous[:-1] + current

    if plain_previous.endswith("/"):
        return previous + current

    return previous + " " + current


def _cleanup_paragraph_text(text: str) -> str:
    text = text.strip()
    text = re.sub(r"\s+[-‐-‒–—―]\s*$", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _starts_like_dialogue(text: str) -> bool:
    text = text.lstrip()
    return bool(text) and text[0] in {"'", '"', "‘", "’", "“", "”"}


def _ends_like_terminal_dialogue(text: str) -> bool:
    text = text.rstrip()
    if not text:
        return False
    return text.endswith((".", "!", "?", "'", '"', "’", "”"))


def _looks_like_short_dialogue_line(line: OCRLine, page_width: int, text: str | None = None) -> bool:
    normalized_text = text if text is not None else line.text.strip()
    if not _starts_like_dialogue(normalized_text):
        return False

    width_ratio = line.width / max(page_width, 1)
    word_count = len(normalized_text.split())

    if width_ratio <= 0.75:
        return True
    if word_count <= 12:
        return True

    return False


def _line_is_visually_short(line: OCRLine, page_width: int) -> bool:
    return (line.width / max(page_width, 1)) <= 0.75


def _line_is_centered(line: OCRLine, page_width: int) -> bool:
    center_x = line.left + (line.width / 2.0)
    page_center = page_width / 2.0
    return abs(center_x - page_center) <= page_width * 0.12


def _looks_like_scene_break(line: OCRLine, page_width: int, text: str) -> bool:
    stripped = text.strip()
    if not stripped:
        return False

    if re.fullmatch(r"[*#~]+", stripped):
        return True

    if re.fullmatch(r"(?:[.·•]\s*){3,}", stripped):
        return True

    if len(stripped.split()) <= 3 and _line_is_centered(line, page_width):
        if stripped == stripped.upper():
            return True

    return False


def paragraphs_from_page(page: PageOCR, lines: list[OCRLine], config: CleanupConfig) -> list[Paragraph]:
    if not lines:
        return []

    left_values = [line.left for line in lines if len(line.text.strip()) >= 5]
    median_left = int(statistics.median(left_values)) if left_values else lines[0].left

    gaps: list[int] = []
    for previous, current in zip(lines, lines[1:]):
        gap = current.top - previous.top
        if gap > 0:
            gaps.append(gap)
    median_gap = statistics.median(gaps) if gaps else 40

    paragraphs: list[Paragraph] = []
    current_text = ""
    current_pages: list[int] = []
    current_first_left = lines[0].left
    current_starts_indented = False
    previous_line: OCRLine | None = None
    previous_text: str = ""

    for line in lines:
        line_text = _normalize_ocr_markup(line.text.strip())
        if not line_text:
            continue

        starts_indented = (line.left - median_left) >= config.indent_threshold_px
        starts_dialogue = _starts_like_dialogue(line_text)
        looks_short_dialogue = _looks_like_short_dialogue_line(line, page.width, line_text)
        looks_scene_break = _looks_like_scene_break(line, page.width, line_text)
        new_paragraph = False

        if previous_line is None:
            new_paragraph = True
        else:
            gap = line.top - previous_line.top
            previous_starts_dialogue = _starts_like_dialogue(previous_text)
            previous_looks_short_dialogue = _looks_like_short_dialogue_line(previous_line, page.width, previous_text)
            previous_visual_short = _line_is_visually_short(previous_line, page.width)

            if gap > median_gap * config.paragraph_gap_ratio:
                new_paragraph = True
            elif looks_scene_break:
                new_paragraph = True
            elif starts_indented:
                new_paragraph = True
            elif starts_dialogue and looks_short_dialogue:
                new_paragraph = True
            elif starts_dialogue and previous_starts_dialogue:
                new_paragraph = True
            elif starts_dialogue and _ends_like_terminal_dialogue(previous_text):
                new_paragraph = True
            elif previous_starts_dialogue and previous_looks_short_dialogue and _ends_like_terminal_dialogue(previous_text):
                new_paragraph = True
            elif previous_visual_short and _ends_like_terminal_dialogue(previous_text) and starts_indented:
                new_paragraph = True

        if new_paragraph:
            if current_text:
                paragraphs.append(
                    Paragraph(
                        text=_cleanup_paragraph_text(current_text),
                        page_indices=current_pages.copy(),
                        starts_indented=current_starts_indented,
                        first_line_left=current_first_left,
                    )
                )
            current_text = line_text
            current_pages = [page.page_index]
            current_first_left = line.left
            current_starts_indented = starts_indented
        else:
            current_text = _join_line_text(current_text, line_text)
            if page.page_index not in current_pages:
                current_pages.append(page.page_index)

        previous_line = line
        previous_text = line_text

    if current_text:
        paragraphs.append(
            Paragraph(
                text=_cleanup_paragraph_text(current_text),
                page_indices=current_pages.copy(),
                starts_indented=current_starts_indented,
                first_line_left=current_first_left,
            )
        )

    return paragraphs


def _is_obvious_section_start(paragraph: Paragraph) -> bool:
    text = paragraph.text.strip()
    if not text:
        return False
    if re.fullmatch(r"chapter\s+\d+", text, flags=re.IGNORECASE):
        return True
    if len(text.split()) <= 4 and text == text.upper():
        return True
    return False


def should_merge_across_pages(previous: Paragraph, current: Paragraph) -> bool:
    prev_text = previous.text.rstrip()
    curr_text = current.text.lstrip()

    if not prev_text or not curr_text:
        return False
    if _is_obvious_section_start(current):
        return False
    if current.starts_indented:
        return False

    plain_prev = _INLINE_TAG_RE.sub("", prev_text)
    plain_curr = _INLINE_TAG_RE.sub("", curr_text)

    if _starts_like_dialogue(curr_text) and _ends_like_terminal_dialogue(prev_text):
        return False

    if plain_prev.endswith("-") and plain_curr[:1].islower():
        return True
    if plain_prev.endswith(TERMINAL_PUNCTUATION):
        return False
    if plain_curr[:1].islower():
        return True
    if plain_curr[:1] in {'"', "'", '“', '‘'}:
        return True
    return True


def merge_paragraphs_across_pages(paragraphs_by_page: list[list[Paragraph]]) -> list[Paragraph]:
    merged: list[Paragraph] = []
    for page_paragraphs in paragraphs_by_page:
        for paragraph in page_paragraphs:
            if merged and should_merge_across_pages(merged[-1], paragraph):
                combined_text = _join_line_text(merged[-1].text, paragraph.text)
                combined_pages = sorted(set(merged[-1].page_indices + paragraph.page_indices))
                merged[-1] = Paragraph(
                    text=combined_text,
                    page_indices=combined_pages,
                    starts_indented=merged[-1].starts_indented,
                    first_line_left=merged[-1].first_line_left,
                )
            else:
                merged.append(paragraph)
    return merged


def clean_pages_to_paragraphs(pages: list[PageOCR], config: CleanupConfig) -> list[Paragraph]:
    repeated_margin_texts = detect_repeated_margin_lines(pages)
    paragraphs_by_page: list[list[Paragraph]] = []

    for page in tqdm(pages, desc="Cleaning text", unit="page", leave=False):
        filtered_lines = filter_page_lines(page=page, repeated_margin_texts=repeated_margin_texts, config=config)
        paragraphs_by_page.append(paragraphs_from_page(page, filtered_lines, config))

    merged = merge_paragraphs_across_pages(paragraphs_by_page)
    return [paragraph for paragraph in merged if paragraph.text.strip()]