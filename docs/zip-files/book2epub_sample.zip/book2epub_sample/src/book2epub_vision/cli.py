from __future__ import annotations

import argparse
from pathlib import Path
from typing import Callable

from .pipeline import (
    assemble_book,
    build_book,
    clean_selected_pdf,
    prepare_crop_review_book,
    render_and_review_book,
    review_book,
    split_book,
)


DEFAULT_CONFIG_PATH = Path("examples/book.json")
ConfigAction = Callable[[str | Path], Path]


def _menu_actions() -> list[tuple[str, ConfigAction]]:
    return [
        ("Clean up the selected PDF", clean_selected_pdf),
        ("Split one full PDF into chapter PDFs", split_book),
        ("Render chapter pages and open the crop review app", render_and_review_book),
        ("Reopen the crop review app", review_book),
        ("Render chapter pages and prepare crop review without opening the app", prepare_crop_review_book),
        ("Assemble approved cropped pages into one PDF per chapter", assemble_book),
        ("Build the EPUB from approved chapter crops", build_book),
    ]


def _config_path(config: Path | None) -> Path:
    return config if config is not None else DEFAULT_CONFIG_PATH


def menu(config: Path | None = None) -> None:
    actions = _menu_actions()
    config_path = _config_path(config)

    print("vision2epub menu")
    print("================")
    print(f"Using config: {config_path}")
    for index, (label, _) in enumerate(actions, start=1):
        print(f"{index}. {label}")
    print("0. Exit")

    while True:
        choice = input("Select an option: ").strip()
        if choice == "0":
            return
        try:
            selected_index = int(choice)
        except ValueError:
            print("Enter a number from the menu.")
            continue
        if 1 <= selected_index <= len(actions):
            break
        print("Enter a valid menu number.")

    _, action = actions[selected_index - 1]
    result = action(config_path)
    print(result)


def _add_optional_config_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "config",
        type=Path,
        nargs="?",
        default=None,
        help=f"Optional path to book.json. Defaults to {DEFAULT_CONFIG_PATH}.",
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="AI-layout-first scanned PDF to EPUB pipeline")
    subparsers = parser.add_subparsers(dest="command", required=True)

    menu_parser = subparsers.add_parser(
        "menu",
        help="Show a numbered menu of actions and run the selected one",
    )
    _add_optional_config_argument(menu_parser)

    clean_parser = subparsers.add_parser(
        "clean",
        help="Clean up the selected PDF before splitting, cropping, assembling, or building",
    )
    _add_optional_config_argument(clean_parser)

    split_parser = subparsers.add_parser(
        "split",
        help="Launch the full-book chapter splitter app and export chapter PDFs from one raw scanned PDF",
    )
    _add_optional_config_argument(split_parser)

    crop_parser = subparsers.add_parser(
        "crop",
        help="Render every chapter to page images, generate crop suggestions, and launch the manual crop review app",
    )
    _add_optional_config_argument(crop_parser)

    review_parser = subparsers.add_parser(
        "review",
        help="Reopen the crop review app without forcing a fresh render first",
    )
    _add_optional_config_argument(review_parser)

    cropapp_parser = subparsers.add_parser(
        "cropApp",
        help="Launch only the crop review app using already-rendered pages and saved suggestions",
    )
    _add_optional_config_argument(cropapp_parser)

    prep_parser = subparsers.add_parser(
        "prepare-crop",
        help="Render pages and generate crop suggestions without opening the review app",
    )
    _add_optional_config_argument(prep_parser)

    build_parser = subparsers.add_parser(
        "build",
        help="Build an EPUB from approved crop boxes in the book JSON config",
    )
    _add_optional_config_argument(build_parser)

    assemble_parser = subparsers.add_parser(
        "assemble",
        help="Assemble approved cropped chapter images into one PDF per chapter",
    )
    _add_optional_config_argument(assemble_parser)

    args = parser.parse_args()
    config_path = _config_path(args.config)

    if args.command == "menu":
        menu(config_path)
        return

    if args.command == "clean":
        cleaned_pdf = clean_selected_pdf(config_path)
        print(cleaned_pdf)
        return

    if args.command == "split":
        state_path = split_book(config_path)
        print(state_path)
        return

    if args.command == "crop":
        manifest = render_and_review_book(config_path)
        print(manifest)
        return

    if args.command == "review":
        manifest = review_book(config_path)
        print(manifest)
        return

    if args.command == "cropApp":
        manifest = review_book(config_path)
        print(manifest)
        return

    if args.command == "prepare-crop":
        manifest = prepare_crop_review_book(config_path)
        print(manifest)
        return

    if args.command == "build":
        output = build_book(config_path)
        print(output)
        return

    if args.command == "assemble":
        output_dir = assemble_book(config_path)
        print(output_dir)
        return

    raise SystemExit(f"Unknown command: {args.command}")


if __name__ == "__main__":
    main()
