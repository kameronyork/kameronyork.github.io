from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any


class SuryaCommandError(RuntimeError):
    pass


def _ensure_command_exists(command: str) -> None:
    if shutil.which(command) is None:
        raise SuryaCommandError(
            f"Command not found: {command}. Install and activate Surya in this environment."
        )


def _run_surya(command: str, input_path: Path, output_dir: Path) -> dict[str, Any]:
    _ensure_command_exists(command)
    output_dir.mkdir(parents=True, exist_ok=True)

    cmd = [command, str(input_path), "--output_dir", str(output_dir)]
    result = subprocess.run(cmd, check=False, text=True)
    if result.returncode != 0:
        raise SuryaCommandError(
            f"{command} failed with exit code {result.returncode}."
        )

    # 1. Old flat output
    results_file = output_dir / "results.json"
    if results_file.exists():
        return json.loads(results_file.read_text(encoding="utf-8"))

    # 2. Known subfolder patterns
    candidate_dirs: list[Path] = []

    for subfolder in ["pages", "cropped", input_path.name]:
        sub_dir = output_dir / subfolder
        if sub_dir.exists():
            candidate_dirs.append(sub_dir)

    # 3. Also consider any subdirectory under output_dir
    for sub_dir in output_dir.iterdir():
        if sub_dir.is_dir() and sub_dir not in candidate_dirs:
            candidate_dirs.append(sub_dir)

    for sub_dir in candidate_dirs:
        json_candidates = sorted(sub_dir.glob("*.json"))

        if len(json_candidates) == 1:
            return json.loads(json_candidates[0].read_text(encoding="utf-8"))

        if len(json_candidates) > 1:
            raise SuryaCommandError(
                f"{command} completed, but produced multiple JSON files in {sub_dir}.\n"
                f"Files: {[str(p) for p in json_candidates]}"
            )

    raise SuryaCommandError(
        f"{command} completed but did not create {results_file} "
        f"or any JSON file in a recognized output subfolder under {output_dir}."
    )


def run_surya_layout(input_path: str | Path, output_dir: str | Path, command: str = "surya_layout") -> dict[str, Any]:
    return _run_surya(command=command, input_path=Path(input_path), output_dir=Path(output_dir))


def run_surya_ocr(input_path: str | Path, output_dir: str | Path, command: str = "surya_ocr") -> dict[str, Any]:
    return _run_surya(command=command, input_path=Path(input_path), output_dir=Path(output_dir))