from __future__ import annotations

import json
import re
import statistics
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from PIL import Image
from tqdm import tqdm

from .models import CropModelConfig
from .surya_io import run_surya_layout, run_surya_ocr


BBox = tuple[int, int, int, int]
CHAPTER_CROP_STATE_FILENAME = "crop_state.json"

_PAGE_NUMBER_TOKEN_RE = re.compile(
    r"^(?:\d{1,5}|[ivxlcdm]{1,12})$",
    re.IGNORECASE,
)


def _clamp_box(box: BBox, width: int, height: int) -> BBox:
    x1, y1, x2, y2 = box
    return (
        max(0, min(x1, width)),
        max(0, min(y1, height)),
        max(0, min(x2, width)),
        max(0, min(y2, height)),
    )


def _page_lookup(results: dict[str, Any], image_name: str) -> dict[str, Any]:
    stem = Path(image_name).stem
    if stem in results:
        value = results[stem]
        if isinstance(value, list):
            return value[0]
        return value

    for key, value in results.items():
        if Path(key).stem == stem:
            if isinstance(value, list):
                return value[0]
            return value

    raise KeyError(f"No Surya result found for image '{image_name}'.")


def _merge_boxes(boxes: list[BBox], margin_px: int, width: int, height: int) -> BBox:
    x1 = min(box[0] for box in boxes) - margin_px
    y1 = min(box[1] for box in boxes) - margin_px
    x2 = max(box[2] for box in boxes) + margin_px
    y2 = max(box[3] for box in boxes) + margin_px
    return _clamp_box((x1, y1, x2, y2), width=width, height=height)



def _merge_boxes_with_margins(
    boxes: list[BBox],
    left_margin_px: int,
    top_margin_px: int,
    right_margin_px: int,
    bottom_margin_px: int,
    width: int,
    height: int,
) -> BBox:
    x1 = min(box[0] for box in boxes) - left_margin_px
    y1 = min(box[1] for box in boxes) - top_margin_px
    x2 = max(box[2] for box in boxes) + right_margin_px
    y2 = max(box[3] for box in boxes) + bottom_margin_px
    return _clamp_box((x1, y1, x2, y2), width=width, height=height)

def _box_width(box: BBox) -> int:
    return max(0, box[2] - box[0])


def _box_height(box: BBox) -> int:
    return max(0, box[3] - box[1])


def _box_area(box: BBox) -> int:
    return _box_width(box) * _box_height(box)


def _box_center_x(box: BBox) -> float:
    return (box[0] + box[2]) / 2.0


def _box_center_y(box: BBox) -> float:
    return (box[1] + box[3]) / 2.0


def _is_centered(box: BBox, page_width: int, tolerance_ratio: float = 0.18) -> bool:
    page_center = page_width / 2.0
    return abs(_box_center_x(box) - page_center) <= page_width * tolerance_ratio


def _ocr_line_box(item: dict[str, Any]) -> BBox | None:
    bbox = item.get("bbox")
    if not bbox or len(bbox) != 4:
        return None
    x1, y1, x2, y2 = [int(round(v)) for v in bbox]
    return (x1, y1, x2, y2)


def _normalize_token_text(text: str) -> str:
    text = text.strip().lower()
    text = text.replace("—", "-").replace("–", "-")
    text = re.sub(r"\s+", " ", text)
    return text


def _is_likely_page_number_text(text: str) -> bool:
    normalized = _normalize_token_text(text)
    if not normalized or len(normalized) > 40:
        return False

    candidate = normalized
    candidate = re.sub(r"^page\s+", "", candidate)
    candidate = re.sub(r"^(?:p|pg)\.?\s*", "", candidate)
    candidate = re.sub(r"^no\.?\s*", "", candidate)
    candidate = candidate.strip()
    candidate = candidate.strip("[](){}<> .,_-:;|/")
    candidate = re.sub(r"^[-:|/]+", "", candidate).strip()
    candidate = re.sub(r"[-:|/]+$", "", candidate).strip()

    if _PAGE_NUMBER_TOKEN_RE.fullmatch(candidate):
        return True

    parts = [part for part in re.split(r"\s*[-|/]\s*", candidate) if part]
    if 1 <= len(parts) <= 2 and all(_PAGE_NUMBER_TOKEN_RE.fullmatch(part) for part in parts):
        return True

    return False


def _line_dict(item: dict[str, Any], page_width: int, page_height: int) -> dict[str, Any] | None:
    text = (item.get("text") or "").strip()
    box = _ocr_line_box(item)
    if not text or box is None:
        return None

    x1, y1, x2, y2 = box
    width = _box_width(box)
    height = _box_height(box)

    return {
        "text": text,
        "box": box,
        "x1": x1,
        "y1": y1,
        "x2": x2,
        "y2": y2,
        "width": width,
        "height": height,
        "cx": _box_center_x(box),
        "cy": _box_center_y(box),
        "width_ratio": width / max(page_width, 1),
        "height_ratio": height / max(page_height, 1),
        "y_ratio": _box_center_y(box) / max(page_height, 1),
        "is_centered": _is_centered(box, page_width),
        "is_page_number": _is_likely_page_number_text(text),
    }


def _median(values: list[float], default: float) -> float:
    if not values:
        return default
    return float(statistics.median(values))


def _horizontal_overlap_ratio(line: dict[str, Any], left: float, right: float) -> float:
    overlap = max(0.0, min(line["x2"], right) - max(line["x1"], left))
    return overlap / max(line["width"], 1.0)


def _estimate_body_column(lines: list[dict[str, Any]], page_width: int) -> tuple[float, float, float]:
    usable = [line for line in lines if not line["is_page_number"]]
    if not usable:
        return (0.0, float(page_width), float(page_width))

    widths = sorted(line["width"] for line in usable)
    pivot = widths[max(0, len(widths) // 2)]
    wide_lines = [line for line in usable if line["width"] >= pivot]
    if len(wide_lines) < 3:
        wide_lines = sorted(usable, key=lambda line: line["width"], reverse=True)[: max(3, len(usable) // 2 or 1)]

    left = _median([line["x1"] for line in wide_lines], 0.0)
    right = _median([line["x2"] for line in wide_lines], float(page_width))

    if right <= left:
        left = min(line["x1"] for line in usable)
        right = max(line["x2"] for line in usable)

    body_width = max(1.0, right - left)
    return (left, right, body_width)


def _is_edge_junk(line: dict[str, Any], page_width: int, page_height: int, body_width: float) -> bool:
    y_ratio = line["y_ratio"]

    if line["is_page_number"] and (y_ratio <= 0.20 or y_ratio >= 0.80):
        return True

    if line["is_centered"] and line["width"] <= body_width * 0.60:
        if y_ratio <= 0.22 or y_ratio >= 0.78:
            return True

    if y_ratio <= 0.20 and line["width"] <= body_width * 0.72 and len(_normalize_token_text(line["text"])) <= 80:
        return True

    return False


def _is_body_anchor(
    line: dict[str, Any],
    body_left: float,
    body_right: float,
    body_width: float,
    page_width: int,
    page_height: int,
) -> bool:
    if _is_edge_junk(line, page_width, page_height, body_width):
        return False

    overlap = _horizontal_overlap_ratio(line, body_left, body_right)
    left_delta = abs(line["x1"] - body_left)
    right_delta = abs(line["x2"] - body_right)

    if overlap >= 0.55:
        return True

    if line["width"] >= body_width * 0.45 and (left_delta <= body_width * 0.20 or right_delta <= body_width * 0.20):
        return True

    return False


def _group_lines(lines: list[dict[str, Any]], gap_threshold: float) -> list[list[dict[str, Any]]]:
    if not lines:
        return []

    groups: list[list[dict[str, Any]]] = [[lines[0]]]
    for line in lines[1:]:
        prev = groups[-1][-1]
        gap = line["y1"] - prev["y2"]
        if gap <= gap_threshold:
            groups[-1].append(line)
        else:
            groups.append([line])
    return groups


def _score_group(group: list[dict[str, Any]]) -> float:
    width_sum = sum(line["width"] for line in group)
    span = group[-1]["y2"] - group[0]["y1"]
    return width_sum + 0.5 * span


def _expand_from_anchor_group(
    all_lines: list[dict[str, Any]],
    anchor_group: list[dict[str, Any]],
    body_left: float,
    body_right: float,
    body_width: float,
    gap_threshold: float,
    page_width: int,
    page_height: int,
) -> list[dict[str, Any]]:
    if not anchor_group:
        return []

    start_idx = all_lines.index(anchor_group[0])
    end_idx = all_lines.index(anchor_group[-1])

    kept_start = start_idx
    while kept_start > 0:
        candidate = all_lines[kept_start - 1]
        current = all_lines[kept_start]
        gap = current["y1"] - candidate["y2"]
        if gap > gap_threshold:
            break
        if _is_edge_junk(candidate, page_width, page_height, body_width):
            break
        overlap = _horizontal_overlap_ratio(candidate, body_left, body_right)
        if overlap >= 0.28 or candidate["x2"] >= body_left + body_width * 0.45:
            kept_start -= 1
            continue
        break

    kept_end = end_idx
    while kept_end + 1 < len(all_lines):
        candidate = all_lines[kept_end + 1]
        current = all_lines[kept_end]
        gap = candidate["y1"] - current["y2"]
        if gap > gap_threshold:
            break
        if _is_edge_junk(candidate, page_width, page_height, body_width):
            break
        overlap = _horizontal_overlap_ratio(candidate, body_left, body_right)
        if overlap >= 0.28 or candidate["x1"] <= body_right - body_width * 0.45:
            kept_end += 1
            continue
        break

    return all_lines[kept_start : kept_end + 1]


def _compute_body_crop_box_from_ocr(
    page_width: int,
    page_height: int,
    ocr_page: dict[str, Any] | None,
    config: CropModelConfig,
) -> BBox | None:
    if not ocr_page:
        return None

    lines: list[dict[str, Any]] = []
    for item in ocr_page.get("text_lines", []):
        line = _line_dict(item, page_width, page_height)
        if line is not None:
            lines.append(line)

    if not lines:
        return None

    lines.sort(key=lambda line: (line["y1"], line["x1"]))

    body_left, body_right, body_width = _estimate_body_column(lines, page_width)

    anchors = [
        line
        for line in lines
        if _is_body_anchor(
            line=line,
            body_left=body_left,
            body_right=body_right,
            body_width=body_width,
            page_width=page_width,
            page_height=page_height,
        )
    ]

    if not anchors:
        return None

    heights = [line["height"] for line in anchors if line["height"] > 0]
    typical_height = _median(heights, default=max(1.0, page_height * 0.02))

    gaps = []
    for prev, curr in zip(anchors, anchors[1:]):
        gap = curr["y1"] - prev["y2"]
        if gap >= 0:
            gaps.append(gap)
    typical_gap = _median(gaps, default=typical_height * 0.55)

    group_gap_threshold = max(typical_height * 3.4, typical_gap * 4.0)
    anchor_groups = _group_lines(anchors, group_gap_threshold)
    anchor_group = max(anchor_groups, key=_score_group)

    expand_gap_threshold = max(typical_height * 2.2, typical_gap * 2.6)
    kept_lines = _expand_from_anchor_group(
        all_lines=lines,
        anchor_group=anchor_group,
        body_left=body_left,
        body_right=body_right,
        body_width=body_width,
        gap_threshold=expand_gap_threshold,
        page_width=page_width,
        page_height=page_height,
    )

    kept_boxes = [line["box"] for line in kept_lines if not line["is_page_number"]]
    if not kept_boxes:
        return None

    return _merge_boxes(kept_boxes, margin_px=config.margin_px, width=page_width, height=page_height)


def _is_likely_top_header(box: BBox, page_width: int, page_height: int) -> bool:
    width = _box_width(box)
    height = _box_height(box)

    top_ratio = box[1] / max(page_height, 1)
    width_ratio = width / max(page_width, 1)
    height_ratio = height / max(page_height, 1)

    if top_ratio <= 0.14 and _is_centered(box, page_width):
        if width_ratio <= 0.35 and height_ratio <= 0.08:
            return True

    return False


def _is_likely_bottom_footer(box: BBox, page_width: int, page_height: int) -> bool:
    width = _box_width(box)
    height = _box_height(box)

    bottom_ratio = box[3] / max(page_height, 1)
    width_ratio = width / max(page_width, 1)
    height_ratio = height / max(page_height, 1)
    area_ratio = (width * height) / max(page_width * page_height, 1)
    center_y_ratio = _box_center_y(box) / max(page_height, 1)

    if center_y_ratio >= 0.86:
        if width_ratio <= 0.20 and area_ratio <= 0.02:
            return True
        if bottom_ratio >= 0.90 and width_ratio <= 0.28 and height_ratio <= 0.12:
            return True

    return False


def _filter_body_boxes(
    boxes: list[BBox],
    page_width: int,
    page_height: int,
) -> list[BBox]:
    if not boxes:
        return boxes

    filtered: list[BBox] = []
    for box in boxes:
        if _is_likely_top_header(box, page_width, page_height):
            continue
        if _is_likely_bottom_footer(box, page_width, page_height):
            continue
        filtered.append(box)

    return filtered


def _compute_body_crop_box_from_layout(
    page_width: int,
    page_height: int,
    layout_page: dict[str, Any],
    config: CropModelConfig,
) -> BBox:
    candidates: list[BBox] = []
    min_area = page_width * page_height * config.min_box_area_ratio

    for item in layout_page.get("bboxes", []):
        bbox = item.get("bbox")
        if not bbox or len(bbox) != 4:
            continue

        x1, y1, x2, y2 = [int(round(v)) for v in bbox]
        box = (x1, y1, x2, y2)
        if _box_area(box) < min_area:
            continue
        candidates.append(box)

    if not candidates:
        return (0, 0, page_width, page_height)

    filtered = _filter_body_boxes(candidates, page_width, page_height)
    if filtered:
        candidates = filtered

    candidates.sort(key=lambda box: _box_area(box), reverse=True)
    candidates = candidates[: config.max_boxes]
    candidates.sort(key=lambda box: (box[1], box[0]))
    return _merge_boxes(candidates, margin_px=config.margin_px, width=page_width, height=page_height)


def _read_grayscale(page_path: Path) -> np.ndarray:
    image = cv2.imread(str(page_path), cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"Could not read image: {page_path}")
    return image


def _find_fast_text_boxes(page_path: Path, page_width: int, page_height: int, config: CropModelConfig) -> list[BBox]:
    gray = _read_grayscale(page_path)

    max_dim = max(gray.shape)
    scale = 1.0
    if max_dim > 1600:
        scale = 1600.0 / float(max_dim)
        gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)

    blurred = cv2.GaussianBlur(gray, (3, 3), 0)
    _, mask = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    h, w = mask.shape
    horiz = max(8, int(round(w * 0.02)))
    vert = max(3, int(round(h * 0.006)))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (horiz, vert))
    merged = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)

    num_labels, _, stats, _ = cv2.connectedComponentsWithStats(merged, connectivity=8)
    min_area = max(12, int(round((w * h) * max(config.min_box_area_ratio * 0.33, 0.00008))))

    boxes: list[BBox] = []
    for idx in range(1, num_labels):
        x, y, bw, bh, area = stats[idx]
        if area < min_area:
            continue
        if bw < 10 or bh < 4:
            continue

        x1 = int(round(x / scale))
        y1 = int(round(y / scale))
        x2 = int(round((x + bw) / scale))
        y2 = int(round((y + bh) / scale))
        box = _clamp_box((x1, y1, x2, y2), page_width, page_height)
        boxes.append(box)

    return boxes


def _compute_fast_body_crop_box(page_path: Path, page_width: int, page_height: int, config: CropModelConfig) -> BBox:
    candidates = _find_fast_text_boxes(page_path, page_width, page_height, config)
    if not candidates:
        return (0, 0, page_width, page_height)

    filtered = _filter_body_boxes(candidates, page_width, page_height)
    if filtered:
        candidates = filtered

    candidates.sort(key=lambda box: _box_area(box), reverse=True)
    candidates = candidates[: max(30, min(config.max_boxes, 80))]
    candidates.sort(key=lambda box: (box[1], box[0]))
    return _merge_boxes_with_margins(
        candidates,
        left_margin_px=max(config.margin_px, 30),
        top_margin_px=max(config.margin_px * 4, 120),
        right_margin_px=max(config.margin_px, 30),
        bottom_margin_px=max(config.margin_px * 2, 45),
        width=page_width,
        height=page_height,
    )


def compute_body_crop_box(
    page_width: int,
    page_height: int,
    layout_page: dict[str, Any],
    config: CropModelConfig,
    ocr_page: dict[str, Any] | None = None,
) -> BBox:
    ocr_box = _compute_body_crop_box_from_ocr(
        page_width=page_width,
        page_height=page_height,
        ocr_page=ocr_page,
        config=config,
    )
    if ocr_box is not None:
        return ocr_box

    return _compute_body_crop_box_from_layout(
        page_width=page_width,
        page_height=page_height,
        layout_page=layout_page,
        config=config,
    )


def propose_crop_boxes_with_surya(
    page_paths: list[Path],
    layout_dir: Path,
    config: CropModelConfig,
) -> dict[str, BBox]:
    if not page_paths:
        return {}

    layout_dir.mkdir(parents=True, exist_ok=True)

    results = run_surya_layout(
        input_path=page_paths[0].parent,
        output_dir=layout_dir,
        command=config.layout_command,
    )
    ocr_results = run_surya_ocr(
        input_path=page_paths[0].parent,
        output_dir=layout_dir / "ocr",
        command=getattr(config, "ocr_command", "surya_ocr"),
    )

    crop_boxes: dict[str, BBox] = {}
    for page_path in tqdm(page_paths, desc="Proposing crop boxes", unit="page", leave=False):
        image = Image.open(page_path)
        try:
            width, height = image.size
        finally:
            image.close()

        layout_page = _page_lookup(results, page_path.name)
        ocr_page = _page_lookup(ocr_results, page_path.name)
        crop_boxes[page_path.name] = compute_body_crop_box(
            width,
            height,
            layout_page,
            config,
            ocr_page=ocr_page,
        )

    return crop_boxes


def propose_crop_boxes_fast(
    page_paths: list[Path],
    config: CropModelConfig,
) -> dict[str, BBox]:
    crop_boxes: dict[str, BBox] = {}
    for page_path in tqdm(page_paths, desc="Proposing fast crop boxes", unit="page", leave=False):
        image = Image.open(page_path)
        try:
            width, height = image.size
        finally:
            image.close()
        crop_boxes[page_path.name] = _compute_fast_body_crop_box(page_path, width, height, config)
    return crop_boxes


def apply_crop_boxes(
    page_paths: list[Path],
    cropped_dir: Path,
    crop_boxes: dict[str, BBox],
) -> dict[str, BBox]:
    cropped_dir.mkdir(parents=True, exist_ok=True)

    applied: dict[str, BBox] = {}
    for page_path in tqdm(page_paths, desc="Saving cropped pages", unit="page", leave=False):
        image = Image.open(page_path)
        try:
            width, height = image.size
            box = crop_boxes.get(page_path.name, (0, 0, width, height))
            clamped = _clamp_box(box, width, height)
            cropped = image.crop(clamped)
            cropped.save(cropped_dir / page_path.name)
            applied[page_path.name] = clamped
        finally:
            image.close()

    return applied


def deserialize_box(value: object) -> BBox | None:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        return None
    try:
        x1, y1, x2, y2 = [int(round(float(component))) for component in value]
    except (TypeError, ValueError):
        return None
    return (x1, y1, x2, y2)


def chapter_crop_state_path(layout_dir: Path) -> Path:
    return layout_dir / CHAPTER_CROP_STATE_FILENAME


def load_chapter_crop_state(layout_dir: Path) -> dict[str, Any]:
    path = chapter_crop_state_path(layout_dir)
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def save_chapter_crop_state(layout_dir: Path, state: dict[str, Any]) -> Path:
    layout_dir.mkdir(parents=True, exist_ok=True)
    path = chapter_crop_state_path(layout_dir)
    path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    return path
