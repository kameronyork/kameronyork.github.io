from __future__ import annotations

from pathlib import Path

from PIL import Image
from tqdm import tqdm

from .ai_crop import (
    apply_crop_boxes,
    deserialize_box,
    load_chapter_crop_state,
    propose_crop_boxes_fast,
    save_chapter_crop_state,
)
from .chapter_splitter import launch_chapter_split_app, prepare_chapter_split_state
from .cleaning import clean_pages_to_paragraphs
from .config import load_config
from .crop_review import launch_crop_review_app, save_crop_review_manifest
from .epub import build_epub
from .pdf_cleanup import clean_pdf_in_place
from .preprocess import preprocess_chapter_images_for_ocr
from .render import render_pdf_to_images
from .surya_ocr import ocr_chapter_images_with_surya
from .xhtml import chapter_xhtml


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}


def _sorted_image_paths(directory: Path) -> list[Path]:
    return sorted(
        path
        for path in directory.iterdir()
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    )


def _ensure_rendered_pages(
    chapter_pdf: Path,
    pages_dir: Path,
    render_dpi: int,
) -> list[Path]:
    rendered_pages = _sorted_image_paths(pages_dir)
    if rendered_pages:
        return rendered_pages

    return render_pdf_to_images(chapter_pdf, pages_dir, dpi=render_dpi)


def _render_pages_fresh(
    chapter_pdf: Path,
    pages_dir: Path,
    render_dpi: int,
) -> list[Path]:
    for image_path in _sorted_image_paths(pages_dir):
        image_path.unlink()
    return render_pdf_to_images(chapter_pdf, pages_dir, dpi=render_dpi)


def _image_size(page_path: Path) -> tuple[int, int]:
    image = Image.open(page_path)
    try:
        return image.size
    finally:
        image.close()


def _chapter_directories(work_dir: Path, chapter_id: str) -> dict[str, Path]:
    chapter_dir = work_dir / chapter_id
    pages_dir = chapter_dir / "pages"
    layout_dir = chapter_dir / "layout"
    cropped_dir = chapter_dir / "cropped"
    ocr_input_dir = chapter_dir / "ocr_input"
    ocr_dir = chapter_dir / "ocr"
    cleaned_dir = chapter_dir / "cleaned"
    xhtml_dir = chapter_dir / "xhtml"

    for directory in [pages_dir, layout_dir, cropped_dir, ocr_input_dir, ocr_dir, cleaned_dir, xhtml_dir]:
        directory.mkdir(parents=True, exist_ok=True)

    return {
        "chapter_dir": chapter_dir,
        "pages_dir": pages_dir,
        "layout_dir": layout_dir,
        "cropped_dir": cropped_dir,
        "ocr_input_dir": ocr_input_dir,
        "ocr_dir": ocr_dir,
        "cleaned_dir": cleaned_dir,
        "xhtml_dir": xhtml_dir,
    }


def _existing_suggestions_cover_all_pages(existing_pages: dict[str, object], page_paths: list[Path]) -> bool:
    if not page_paths:
        return False

    for page_path in page_paths:
        entry = existing_pages.get(page_path.name)
        if not isinstance(entry, dict):
            return False
        if deserialize_box(entry.get("suggested_box")) is None:
            return False

    return True


def _prepare_chapter_review_state(
    chapter,
    page_paths: list[Path],
    cropped_dir: Path,
    layout_dir: Path,
    crop_model,
) -> Path:
    existing_state = load_chapter_crop_state(layout_dir)
    existing_pages = existing_state.get("pages", {}) if isinstance(existing_state.get("pages"), dict) else {}

    if _existing_suggestions_cover_all_pages(existing_pages, page_paths):
        suggestions = {
            page_path.name: deserialize_box(existing_pages[page_path.name].get("suggested_box"))
            for page_path in page_paths
        }
    else:
        suggestions = propose_crop_boxes_fast(
            page_paths=page_paths,
            config=crop_model,
        )

    state_pages: dict[str, dict[str, object]] = {}
    for page_path in page_paths:
        width, height = _image_size(page_path)
        existing_entry = existing_pages.get(page_path.name, {}) if isinstance(existing_pages.get(page_path.name), dict) else {}
        suggested_box = suggestions.get(page_path.name) or deserialize_box(existing_entry.get("suggested_box"))
        approved_box = deserialize_box(existing_entry.get("approved_box"))

        if suggested_box is None:
            suggested_box = (0, 0, width, height)

        state_pages[page_path.name] = {
            "page_name": page_path.name,
            "page_path": str(page_path.resolve()),
            "cropped_path": str((cropped_dir / page_path.name).resolve()),
            "image_size": [width, height],
            "suggested_box": [int(suggested_box[0]), int(suggested_box[1]), int(suggested_box[2]), int(suggested_box[3])],
            "approved_box": (
                [int(approved_box[0]), int(approved_box[1]), int(approved_box[2]), int(approved_box[3])]
                if approved_box is not None
                else None
            ),
            "status": "approved" if approved_box is not None else "pending",
        }

    state = {
        "version": 1,
        "chapter_id": chapter.id,
        "chapter_title": chapter.title,
        "pages": state_pages,
    }
    return save_chapter_crop_state(layout_dir, state)


def _approved_crop_boxes_for_pages(page_paths: list[Path], layout_dir: Path) -> dict[str, tuple[int, int, int, int]]:
    state = load_chapter_crop_state(layout_dir)
    state_pages = state.get("pages", {}) if isinstance(state.get("pages"), dict) else {}

    crop_boxes: dict[str, tuple[int, int, int, int]] = {}
    missing_pages: list[str] = []

    for page_path in page_paths:
        entry = state_pages.get(page_path.name)
        if not isinstance(entry, dict):
            missing_pages.append(page_path.name)
            continue

        approved_box = deserialize_box(entry.get("approved_box"))
        if approved_box is None:
            missing_pages.append(page_path.name)
            continue

        crop_boxes[page_path.name] = approved_box

    if missing_pages:
        missing = ", ".join(missing_pages[:10])
        if len(missing_pages) > 10:
            missing += ", ..."
        raise RuntimeError(
            "Missing approved crop boxes. Run the crop or review command first and approve every page before building. "
            f"Pending pages: {missing}"
        )

    return crop_boxes


def _ensure_reviewed_crops(
    chapter_pdf: Path,
    pages_dir: Path,
    cropped_dir: Path,
    layout_dir: Path,
    render_dpi: int,
) -> list[Path]:
    rendered_pages = _ensure_rendered_pages(chapter_pdf=chapter_pdf, pages_dir=pages_dir, render_dpi=render_dpi)
    approved_boxes = _approved_crop_boxes_for_pages(rendered_pages, layout_dir)
    apply_crop_boxes(page_paths=rendered_pages, cropped_dir=cropped_dir, crop_boxes=approved_boxes)
    return [cropped_dir / page_path.name for page_path in rendered_pages]


def _save_images_as_pdf(image_paths: list[Path], output_pdf: Path) -> Path:
    if not image_paths:
        raise ValueError(f"No images found to assemble into PDF: {output_pdf}")

    output_pdf.parent.mkdir(parents=True, exist_ok=True)

    images: list[Image.Image] = []
    try:
        for image_path in image_paths:
            image = Image.open(image_path)
            if image.mode != "RGB":
                image = image.convert("RGB")
            else:
                image = image.copy()
            images.append(image)

        first, *rest = images
        first.save(output_pdf, save_all=True, append_images=rest, format="PDF", resolution=300.0)
        return output_pdf
    finally:
        for image in images:
            image.close()


def _prepare_review_manifest(config, *, render_fresh: bool) -> Path:
    rendered_pages_by_index: list[list[Path]] = []
    render_desc = "Rendering chapters" if render_fresh else "Checking chapter pages"

    for chapter in tqdm(config.chapters, desc=render_desc, unit="chapter"):
        directories = _chapter_directories(config.work_dir, chapter.id)
        page_paths = (
            _render_pages_fresh(
                chapter_pdf=chapter.pdf,
                pages_dir=directories["pages_dir"],
                render_dpi=config.render_dpi,
            )
            if render_fresh
            else _ensure_rendered_pages(
                chapter_pdf=chapter.pdf,
                pages_dir=directories["pages_dir"],
                render_dpi=config.render_dpi,
            )
        )
        rendered_pages_by_index.append(page_paths)

    chapter_entries: list[dict[str, str]] = []
    for chapter_index, chapter in enumerate(tqdm(config.chapters, desc="Preparing crop review", unit="chapter")):
        directories = _chapter_directories(config.work_dir, chapter.id)
        state_path = _prepare_chapter_review_state(
            chapter=chapter,
            page_paths=rendered_pages_by_index[chapter_index],
            cropped_dir=directories["cropped_dir"],
            layout_dir=directories["layout_dir"],
            crop_model=config.crop_model,
        )
        chapter_entries.append(
            {
                "chapter_id": chapter.id,
                "chapter_title": chapter.title,
                "state_path": str(state_path.resolve()),
            }
        )

    return save_crop_review_manifest(config.work_dir, chapter_entries)


def clean_selected_pdf(config_path: str | Path) -> Path:
    config = load_config(config_path)
    if config.full_book is None:
        raise RuntimeError(
            "This config does not define a 'full_book' section. Add 'full_book.pdf' to book.json before cleaning."
        )

    return clean_pdf_in_place(config.full_book.pdf)


def split_book(config_path: str | Path) -> Path:
    config = load_config(config_path)
    config.work_dir.mkdir(parents=True, exist_ok=True)
    state_path = prepare_chapter_split_state(config)
    launch_chapter_split_app(state_path)
    return state_path


def prepare_crop_review_book(config_path: str | Path) -> Path:
    config = load_config(config_path)
    config.work_dir.mkdir(parents=True, exist_ok=True)
    return _prepare_review_manifest(config, render_fresh=True)


def render_and_review_book(config_path: str | Path) -> Path:
    manifest_path = prepare_crop_review_book(config_path)
    launch_crop_review_app(manifest_path)
    return manifest_path


def review_book(config_path: str | Path) -> Path:
    config = load_config(config_path)
    config.work_dir.mkdir(parents=True, exist_ok=True)

    manifest_path = _prepare_review_manifest(config, render_fresh=False)
    launch_crop_review_app(manifest_path)
    return manifest_path


def assemble_book(config_path: str | Path) -> Path:
    config = load_config(config_path)
    config.work_dir.mkdir(parents=True, exist_ok=True)

    assembled_root = config.work_dir / "assembled"
    assembled_root.mkdir(parents=True, exist_ok=True)

    for chapter in tqdm(config.chapters, desc="Chapters", unit="chapter"):
        directories = _chapter_directories(config.work_dir, chapter.id)

        cropped_pages = _ensure_reviewed_crops(
            chapter_pdf=chapter.pdf,
            pages_dir=directories["pages_dir"],
            cropped_dir=directories["cropped_dir"],
            layout_dir=directories["layout_dir"],
            render_dpi=config.render_dpi,
        )

        chapter_pdf_output = assembled_root / f"{chapter.id}.pdf"
        _save_images_as_pdf(cropped_pages, chapter_pdf_output)

    return assembled_root


def build_book(config_path: str | Path) -> Path:
    config = load_config(config_path)
    config.work_dir.mkdir(parents=True, exist_ok=True)

    chapter_payloads: list[tuple[str, str, str]] = []

    for chapter in tqdm(config.chapters, desc="Chapters", unit="chapter"):
        directories = _chapter_directories(config.work_dir, chapter.id)

        cropped_pages = _ensure_reviewed_crops(
            chapter_pdf=chapter.pdf,
            pages_dir=directories["pages_dir"],
            cropped_dir=directories["cropped_dir"],
            layout_dir=directories["layout_dir"],
            render_dpi=config.render_dpi,
        )

        ocr_input_pages = preprocess_chapter_images_for_ocr(
            cropped_pages,
            output_dir=directories["ocr_input_dir"],
        )

        ocr_pages = ocr_chapter_images_with_surya(
            ocr_input_pages,
            ocr_dir=directories["ocr_dir"],
            command=config.crop_model.ocr_command,
        )

        paragraphs = clean_pages_to_paragraphs(pages=ocr_pages, config=config.cleanup)
        cleaned_text = "\n\n".join(paragraph.text for paragraph in paragraphs)
        (directories["cleaned_dir"] / f"{chapter.id}.txt").write_text(cleaned_text, encoding="utf-8")

        xhtml = chapter_xhtml(chapter.title, paragraphs, language=config.language)
        xhtml_filename = f"{chapter.id}.xhtml"
        (directories["xhtml_dir"] / xhtml_filename).write_text(xhtml, encoding="utf-8")
        chapter_payloads.append((xhtml_filename, chapter.title, xhtml))

    return build_epub(
        output_epub=config.output_epub,
        title=config.title,
        author=config.author,
        language=config.language,
        identifier=config.identifier,
        chapters=chapter_payloads,
    )
