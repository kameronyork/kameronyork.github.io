from __future__ import annotations

import re
from html import escape

from .models import Paragraph


DEFAULT_CSS = """
body {
  margin: 5%;
  line-height: 1.45;
  font-family: serif;
}
h1 {
  text-align: center;
  margin: 2em 0 1.5em 0;
}
p {
  text-indent: 1.2em;
  margin: 0;
}
p.noindent {
  text-indent: 0;
}
""".strip()

_INLINE_TAG_PATTERN = re.compile(
    r"(</?(?:i|em|b|strong|sub|sup)\s*>|<br\s*/?>)",
    flags=re.IGNORECASE,
)


def _escape_text_preserving_inline_markup(text: str) -> str:
    parts = _INLINE_TAG_PATTERN.split(text)
    out: list[str] = []

    for part in parts:
        if not part:
            continue
        if _INLINE_TAG_PATTERN.fullmatch(part):
            normalized = part.strip().lower()
            normalized = re.sub(r"\s+", "", normalized)
            if normalized in {"<br>", "<br/>"}:
                out.append("<br/>")
            else:
                out.append(normalized)
        else:
            out.append(escape(part))

    return "".join(out)


def chapter_xhtml(title: str, paragraphs: list[Paragraph], language: str = "en") -> str:
    paragraph_html: list[str] = []
    for idx, paragraph in enumerate(paragraphs):
        klass = "noindent" if idx == 0 else ""
        class_attr = f' class="{klass}"' if klass else ""
        rendered_text = _escape_text_preserving_inline_markup(paragraph.text)
        paragraph_html.append(f"    <p{class_attr}>{rendered_text}</p>")

    joined = "\n".join(paragraph_html)
    return f"""<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{escape(language)}" lang="{escape(language)}">
  <head>
    <title>{escape(title)}</title>
    <link rel="stylesheet" type="text/css" href="../styles/book.css"/>
  </head>
  <body>
    <h1>{escape(title)}</h1>
{joined}
  </body>
</html>
"""


def nav_xhtml(book_title: str, chapter_files: list[tuple[str, str]], language: str = "en") -> str:
    items = "\n".join(
        f'        <li><a href="Text/{escape(filename)}">{escape(title)}</a></li>'
        for filename, title in chapter_files
    )
    return f"""<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="{escape(language)}" lang="{escape(language)}">
  <head>
    <title>{escape(book_title)}</title>
  </head>
  <body>
    <nav epub:type="toc" id="toc">
      <h1>{escape(book_title)}</h1>
      <ol>
{items}
      </ol>
    </nav>
  </body>
</html>
"""


def toc_ncx(book_title: str, identifier: str, chapter_files: list[tuple[str, str]]) -> str:
    points: list[str] = []
    for idx, (filename, title) in enumerate(chapter_files, start=1):
        points.append(
            f"""    <navPoint id="navPoint-{idx}" playOrder="{idx}">
      <navLabel><text>{escape(title)}</text></navLabel>
      <content src="Text/{escape(filename)}"/>
    </navPoint>"""
        )
    joined = "\n".join(points)
    return f"""<?xml version="1.0" encoding="utf-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="{escape(identifier)}"/>
    <meta name="dtb:depth" content="1"/>
    <meta name="dtb:totalPageCount" content="0"/>
    <meta name="dtb:maxPageNumber" content="0"/>
  </head>
  <docTitle><text>{escape(book_title)}</text></docTitle>
  <navMap>
{joined}
  </navMap>
</ncx>
"""