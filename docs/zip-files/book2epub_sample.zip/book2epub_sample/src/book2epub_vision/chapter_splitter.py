from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from tkinter import messagebox, ttk
import tkinter as tk
from typing import Any

import fitz
from PIL import Image, ImageTk

from .models import BookConfig
from .render import render_pdf_to_images


try:
    RESAMPLE_LANCZOS = Image.Resampling.LANCZOS
except AttributeError:  # Pillow < 9
    RESAMPLE_LANCZOS = Image.LANCZOS


CHAPTER_SPLIT_STATE_FILENAME = "chapter_split_state.json"
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}

BG = "#f3f6fb"
CARD_BG = "#ffffff"
TEXT = "#1f2937"
MUTED = "#6b7280"
ACCENT = "#4f46e5"
ACCENT_DARK = "#4338ca"
SUCCESS = "#10b981"
SUCCESS_DARK = "#059669"
WARNING = "#f59e0b"
WARNING_DARK = "#d97706"
DANGER = "#ef4444"
CANVAS_BG = "#0f172a"
GUIDE = "#93c5fd"
LINE_CURRENT_START = "#f59e0b"
LINE_CURRENT_END = "#22c55e"
LINE_DONE = "#a78bfa"
LINE_PENDING = "#60a5fa"


@dataclass(slots=True)
class ChapterBoundary:
    page_index: int
    y: int


@dataclass(slots=True)
class RenderedPage:
    page_index: int
    page_path: Path
    width: int
    height: int
    pdf_width: float
    pdf_height: float


@dataclass(slots=True)
class SplitChapter:
    index: int
    id: str
    title: str
    output_pdf: Path


class ChapterSplitError(RuntimeError):
    pass


def _sorted_image_paths(directory: Path) -> list[Path]:
    if not directory.exists():
        return []
    return sorted(
        path
        for path in directory.iterdir()
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    )


def _image_size(page_path: Path) -> tuple[int, int]:
    image = Image.open(page_path)
    try:
        return image.size
    finally:
        image.close()


def _clear_directory_files(directory: Path) -> None:
    if not directory.exists():
        return
    for path in directory.iterdir():
        if path.is_file():
            path.unlink()


def _file_signature(path: Path) -> dict[str, object]:
    stat = path.stat()
    return {
        "path": str(path.resolve()),
        "size": int(stat.st_size),
        "mtime_ns": int(stat.st_mtime_ns),
    }


def _state_matches_source(state: dict[str, Any], source_pdf: Path, render_dpi: int) -> bool:
    if not state:
        return False
    if state.get("source_pdf") != str(source_pdf.resolve()):
        return False
    if int(state.get("render_dpi", 0)) != int(render_dpi):
        return False

    signature = state.get("source_signature")
    if not isinstance(signature, dict):
        return False

    expected = _file_signature(source_pdf)
    for key in ("path", "size", "mtime_ns"):
        if signature.get(key) != expected.get(key):
            return False

    pages = state.get("pages")
    if not isinstance(pages, list) or not pages:
        return False

    for page in pages:
        if not isinstance(page, dict):
            return False
        page_path = Path(str(page.get("page_path", "")))
        if not page_path.exists():
            return False

    return True


def chapter_split_state_path(split_dir: Path) -> Path:
    return split_dir / CHAPTER_SPLIT_STATE_FILENAME


def load_chapter_split_state(state_path: Path) -> dict[str, Any]:
    if not state_path.exists():
        return {}
    raw = json.loads(state_path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ChapterSplitError(f"Invalid chapter split state file: {state_path}")
    return raw


def save_chapter_split_state(state_path: Path, state: dict[str, Any]) -> Path:
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    return state_path


def deserialize_boundary(value: object) -> ChapterBoundary | None:
    if value is None:
        return None
    if not isinstance(value, dict):
        return None
    try:
        page_index = int(value["page_index"])
        y = int(round(float(value["y"])))
    except (KeyError, TypeError, ValueError):
        return None
    if page_index < 0:
        return None
    return ChapterBoundary(page_index=page_index, y=y)


def serialize_boundary(boundary: ChapterBoundary | None) -> dict[str, int] | None:
    if boundary is None:
        return None
    return {
        "page_index": int(boundary.page_index),
        "y": int(boundary.y),
    }


def _build_pages_payload(page_paths: list[Path], source_pdf: Path) -> list[dict[str, object]]:
    payload: list[dict[str, object]] = []
    doc = fitz.open(source_pdf)
    try:
        if len(doc) != len(page_paths):
            raise ChapterSplitError(
                f"Rendered preview page count ({len(page_paths)}) does not match source PDF page count ({len(doc)})."
            )

        for page_index, page_path in enumerate(page_paths):
            width, height = _image_size(page_path)
            rect = doc[page_index].rect
            payload.append(
                {
                    "page_index": page_index,
                    "page_path": str(page_path.resolve()),
                    "width": width,
                    "height": height,
                    "pdf_width": float(rect.width),
                    "pdf_height": float(rect.height),
                }
            )
    finally:
        doc.close()
    return payload


def _build_chapters_payload(config: BookConfig) -> list[dict[str, object]]:
    return [
        {
            "index": index,
            "id": chapter.id,
            "title": chapter.title,
            "output_pdf": str(chapter.pdf.resolve()),
        }
        for index, chapter in enumerate(config.chapters)
    ]


def _deserialize_pages(raw_pages: list[dict[str, object]]) -> list[RenderedPage]:
    pages: list[RenderedPage] = []
    for item in raw_pages:
        pages.append(
            RenderedPage(
                page_index=int(item["page_index"]),
                page_path=Path(str(item["page_path"])).resolve(),
                width=int(item["width"]),
                height=int(item["height"]),
                pdf_width=float(item.get("pdf_width", item["width"])),
                pdf_height=float(item.get("pdf_height", item["height"])),
            )
        )
    return pages


def _deserialize_chapters(raw_chapters: list[dict[str, object]]) -> list[SplitChapter]:
    chapters: list[SplitChapter] = []
    for item in raw_chapters:
        chapters.append(
            SplitChapter(
                index=int(item["index"]),
                id=str(item["id"]),
                title=str(item["title"]),
                output_pdf=Path(str(item["output_pdf"])).resolve(),
            )
        )
    return chapters


def _validated_boundaries(
    values: list[object],
    page_count: int,
    page_heights: dict[int, int],
    chapter_count: int,
) -> list[dict[str, int] | None]:
    expected_length = chapter_count + 1
    boundaries: list[dict[str, int] | None] = [None] * expected_length
    if len(values) != expected_length:
        return boundaries

    previous: ChapterBoundary | None = None
    for index, value in enumerate(values):
        boundary = deserialize_boundary(value)
        if boundary is None:
            boundaries[index] = None
            continue
        if boundary.page_index >= page_count:
            return [None] * expected_length
        page_height = page_heights.get(boundary.page_index, 0)
        if page_height <= 0:
            return [None] * expected_length
        y = max(0, min(boundary.y, page_height))
        boundary = ChapterBoundary(page_index=boundary.page_index, y=y)
        if previous is not None and not _boundary_is_after(boundary, previous):
            return [None] * expected_length
        previous = boundary
        boundaries[index] = serialize_boundary(boundary)

    return boundaries


def prepare_chapter_split_state(config: BookConfig) -> Path:
    if config.full_book is None:
        raise ChapterSplitError(
            "This config does not define a 'full_book' section. Add 'full_book.pdf' to book.json before using split."
        )

    config.work_dir.mkdir(parents=True, exist_ok=True)
    split_dir = config.work_dir / "chapter_split"
    pages_dir = split_dir / "pages"
    state_path = chapter_split_state_path(split_dir)
    pages_dir.mkdir(parents=True, exist_ok=True)

    existing_state = load_chapter_split_state(state_path)
    source_pdf = config.full_book.pdf.resolve()
    if not source_pdf.exists():
        raise ChapterSplitError(f"Full-book PDF does not exist: {source_pdf}")

    render_dpi = int(config.full_book.preview_dpi)
    reuse_pages = _state_matches_source(existing_state, source_pdf=source_pdf, render_dpi=render_dpi)

    if reuse_pages:
        page_paths = [Path(str(page["page_path"])).resolve() for page in existing_state["pages"]]
    else:
        _clear_directory_files(pages_dir)
        page_paths = render_pdf_to_images(source_pdf, pages_dir, dpi=render_dpi)

    pages_payload = _build_pages_payload(page_paths, source_pdf=source_pdf)
    page_heights = {int(page["page_index"]): int(page["height"]) for page in pages_payload}

    boundaries: list[dict[str, int] | None] = [None] * (len(config.chapters) + 1)
    if reuse_pages and isinstance(existing_state.get("boundaries"), list):
        boundaries = _validated_boundaries(
            values=existing_state["boundaries"],
            page_count=len(pages_payload),
            page_heights=page_heights,
            chapter_count=len(config.chapters),
        )

    state = {
        "version": 1,
        "book_title": config.title,
        "source_pdf": str(source_pdf),
        "source_signature": _file_signature(source_pdf),
        "render_dpi": render_dpi,
        "pages": pages_payload,
        "chapters": _build_chapters_payload(config),
        "boundaries": boundaries,
        "last_exported_at": existing_state.get("last_exported_at") if reuse_pages else None,
    }
    return save_chapter_split_state(state_path, state)


def _boundary_key(boundary: ChapterBoundary) -> tuple[int, int]:
    return (boundary.page_index, boundary.y)


def _boundary_is_after(candidate: ChapterBoundary, previous: ChapterBoundary) -> bool:
    return _boundary_key(candidate) > _boundary_key(previous)


def _normalized_boundary_y(boundary: ChapterBoundary, page: RenderedPage) -> float:
    if page.height <= 0:
        return 0.0
    return max(0.0, min(boundary.y / float(page.height), 1.0))


def _clip_rect_for_page(
    page: RenderedPage,
    pdf_rect: fitz.Rect,
    start: ChapterBoundary,
    end: ChapterBoundary,
) -> fitz.Rect | None:
    top_ratio = _normalized_boundary_y(start, page) if page.page_index == start.page_index else 0.0
    bottom_ratio = _normalized_boundary_y(end, page) if page.page_index == end.page_index else 1.0

    top = pdf_rect.y0 + (pdf_rect.height * top_ratio)
    bottom = pdf_rect.y0 + (pdf_rect.height * bottom_ratio)
    top = max(pdf_rect.y0, min(top, pdf_rect.y1))
    bottom = max(pdf_rect.y0, min(bottom, pdf_rect.y1))
    if bottom <= top:
        return None
    return fitz.Rect(pdf_rect.x0, top, pdf_rect.x1, bottom)


def _export_chapter_pdf_from_source(
    source_pdf: Path,
    pages: list[RenderedPage],
    start: ChapterBoundary,
    end: ChapterBoundary,
    output_pdf: Path,
) -> Path:
    if not _boundary_is_after(end, start):
        raise ChapterSplitError("Every chapter end boundary must come after its start boundary.")

    src_doc = fitz.open(source_pdf)
    out_doc = fitz.open()
    try:
        for page_index in range(start.page_index, end.page_index + 1):
            page = pages[page_index]
            src_page = src_doc[page_index]
            clip = _clip_rect_for_page(page=page, pdf_rect=src_page.rect, start=start, end=end)
            if clip is None:
                continue
            out_page = out_doc.new_page(width=clip.width, height=clip.height)
            out_page.show_pdf_page(out_page.rect, src_doc, page_index, clip=clip)

        if out_doc.page_count == 0:
            raise ChapterSplitError("A chapter boundary pair produced no page content to save.")

        output_pdf.parent.mkdir(parents=True, exist_ok=True)
        out_doc.save(output_pdf)
        return output_pdf
    finally:
        out_doc.close()
        src_doc.close()


def export_chapter_pdfs_from_state(state_path: str | Path) -> list[Path]:
    state_path = Path(state_path).resolve()
    state = load_chapter_split_state(state_path)

    raw_pages = state.get("pages")
    raw_chapters = state.get("chapters")
    raw_boundaries = state.get("boundaries")
    source_pdf = Path(str(state.get("source_pdf", ""))).resolve()

    if not isinstance(raw_pages, list) or not raw_pages:
        raise ChapterSplitError("Split state does not contain rendered pages.")
    if not isinstance(raw_chapters, list) or not raw_chapters:
        raise ChapterSplitError("Split state does not contain chapter definitions.")
    if not isinstance(raw_boundaries, list) or len(raw_boundaries) != len(raw_chapters) + 1:
        raise ChapterSplitError("Split state does not contain a complete boundary list.")

    pages = _deserialize_pages(raw_pages)
    chapters = _deserialize_chapters(raw_chapters)
    boundaries = [deserialize_boundary(value) for value in raw_boundaries]

    if any(boundary is None for boundary in boundaries):
        raise ChapterSplitError("All chapter boundaries must be defined before exporting PDFs.")

    outputs: list[Path] = []
    for chapter_index, chapter in enumerate(chapters):
        start = boundaries[chapter_index]
        end = boundaries[chapter_index + 1]
        if start is None or end is None:
            raise ChapterSplitError("All chapter boundaries must be defined before exporting PDFs.")
        output_path = _export_chapter_pdf_from_source(
            source_pdf=source_pdf,
            pages=pages,
            start=start,
            end=end,
            output_pdf=chapter.output_pdf,
        )
        outputs.append(output_path)

    state["last_exported_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    save_chapter_split_state(state_path, state)
    return outputs


class ChapterSplitApp:
    def __init__(self, state_path: Path) -> None:
        self.state_path = state_path.resolve()
        self.state = load_chapter_split_state(self.state_path)
        self.pages = _deserialize_pages(self.state.get("pages", []))
        self.chapters = _deserialize_chapters(self.state.get("chapters", []))
        self.boundaries: list[ChapterBoundary | None] = [
            deserialize_boundary(value) for value in self.state.get("boundaries", [])
        ]

        if not self.pages:
            raise ChapterSplitError(f"No rendered pages found in split state: {self.state_path}")
        if len(self.boundaries) != len(self.chapters) + 1:
            self.boundaries = [None] * (len(self.chapters) + 1)

        self.current_page_index = self._initial_page_index()
        self.current_image: Image.Image | None = None
        self.tk_image: ImageTk.PhotoImage | None = None
        self.cached_display_size: tuple[int, int] | None = None
        self.scale = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.hover_y: int | None = None

        self.root = tk.Tk()
        self.root.title("Chapter Split Studio")
        self.root.geometry("1540x980")
        self.root.minsize(1160, 760)
        self.root.configure(background=BG)

        self.progress_var = tk.StringVar(value="")
        self.page_var = tk.StringVar(value="")
        self.chapter_var = tk.StringVar(value="")
        self.output_var = tk.StringVar(value="")
        self.instructions_var = tk.StringVar(value="")
        self.boundary_var = tk.StringVar(value="")
        self.status_var = tk.StringVar(value="")
        self.export_var = tk.StringVar(value="")

        self._configure_style()
        self._build_layout()
        self._bind_events()
        self.root.after(10, self._show_current_page)

    def run(self) -> None:
        self.root.mainloop()

    def _configure_style(self) -> None:
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("App.TFrame", background=BG)
        style.configure("Card.TFrame", background=CARD_BG, borderwidth=1, relief="solid")
        style.configure("CardInner.TFrame", background=CARD_BG)
        style.configure("Title.TLabel", background=BG, foreground=TEXT, font=("TkDefaultFont", 20, "bold"))
        style.configure("Subtitle.TLabel", background=BG, foreground=MUTED, font=("TkDefaultFont", 10))
        style.configure("CardTitle.TLabel", background=CARD_BG, foreground=TEXT, font=("TkDefaultFont", 11, "bold"))
        style.configure("CardBody.TLabel", background=CARD_BG, foreground=TEXT, font=("TkDefaultFont", 10))
        style.configure("MutedCard.TLabel", background=CARD_BG, foreground=MUTED, font=("TkDefaultFont", 10))
        style.configure("StrongCard.TLabel", background=CARD_BG, foreground=TEXT, font=("TkDefaultFont", 12, "bold"))
        style.configure("Accent.TButton", background=ACCENT, foreground="#ffffff", padding=(14, 8), relief="flat")
        style.map(
            "Accent.TButton",
            background=[("pressed", ACCENT_DARK), ("active", ACCENT_DARK)],
            foreground=[("!disabled", "#ffffff"), ("disabled", "#d1d5db")],
        )
        style.configure("Secondary.TButton", background="#e8eefc", foreground=ACCENT, padding=(12, 8), relief="flat")
        style.map(
            "Secondary.TButton",
            background=[("pressed", "#dbe4ff"), ("active", "#dbe4ff")],
            foreground=[("!disabled", ACCENT)],
        )
        style.configure("Ghost.TButton", background="#f8fafc", foreground=TEXT, padding=(12, 8), relief="flat")
        style.map(
            "Ghost.TButton",
            background=[("pressed", "#eef2f7"), ("active", "#eef2f7")],
            foreground=[("!disabled", TEXT)],
        )
        style.configure("Treeview", background="#ffffff", foreground=TEXT, fieldbackground="#ffffff", rowheight=28)
        style.configure("Treeview.Heading", background="#eef2ff", foreground=TEXT, relief="flat", font=("TkDefaultFont", 10, "bold"))
        style.map("Treeview", background=[("selected", "#dde7ff")], foreground=[("selected", TEXT)])

    def _build_layout(self) -> None:
        self.root.rowconfigure(0, weight=1)
        self.root.columnconfigure(0, weight=1)

        main = ttk.Frame(self.root, style="App.TFrame", padding=(18, 18, 18, 18))
        main.grid(row=0, column=0, sticky="nsew")
        main.rowconfigure(2, weight=1)
        main.columnconfigure(0, weight=1)

        header = ttk.Frame(main, style="App.TFrame")
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)

        title_group = ttk.Frame(header, style="App.TFrame")
        title_group.grid(row=0, column=0, sticky="w")
        ttk.Label(title_group, text="Chapter Split Studio", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            title_group,
            text="Click horizontal boundaries to carve one full scanned PDF into per-chapter PDFs for the existing OCR workflow.",
            style="Subtitle.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(2, 0))

        header_actions = ttk.Frame(header, style="App.TFrame")
        header_actions.grid(row=0, column=1, sticky="e")
        self.export_button = ttk.Button(header_actions, text="Export PDFs", style="Accent.TButton", command=self.export_pdfs)
        self.export_button.grid(row=0, column=0, padx=(0, 8))
        ttk.Button(header_actions, text="Close", style="Ghost.TButton", command=self.close).grid(row=0, column=1)

        info_card = ttk.Frame(main, style="Card.TFrame", padding=(14, 12, 14, 12))
        info_card.grid(row=1, column=0, sticky="ew", pady=(14, 14))
        info_card.columnconfigure(0, weight=1)
        ttk.Label(info_card, textvariable=self.progress_var, style="StrongCard.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(info_card, textvariable=self.status_var, style="MutedCard.TLabel").grid(row=1, column=0, sticky="w", pady=(2, 0))

        content = ttk.Frame(main, style="App.TFrame")
        content.grid(row=2, column=0, sticky="nsew")
        content.rowconfigure(0, weight=1)
        content.columnconfigure(0, weight=5)
        content.columnconfigure(1, weight=3)

        viewer_card = ttk.Frame(content, style="Card.TFrame", padding=(12, 12, 12, 12))
        viewer_card.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        viewer_card.rowconfigure(0, weight=1)
        viewer_card.columnconfigure(0, weight=1)

        self.canvas = tk.Canvas(viewer_card, background=CANVAS_BG, highlightthickness=0, bd=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")

        toolbar = ttk.Frame(viewer_card, style="CardInner.TFrame")
        toolbar.grid(row=1, column=0, sticky="ew", pady=(12, 0))
        toolbar.columnconfigure(8, weight=1)

        self.prev_button = ttk.Button(toolbar, text="◀ Prev Page", style="Ghost.TButton", command=self.go_previous_page)
        self.prev_button.grid(row=0, column=0, padx=(0, 8))

        self.next_button = ttk.Button(toolbar, text="Next Page ▶", style="Ghost.TButton", command=self.go_next_page)
        self.next_button.grid(row=0, column=1, padx=(0, 8))

        ttk.Button(toolbar, text="Top of Page", style="Secondary.TButton", command=self.use_top_of_page).grid(
            row=0, column=2, padx=(0, 8)
        )
        ttk.Button(toolbar, text="Bottom of Page", style="Secondary.TButton", command=self.use_bottom_of_page).grid(
            row=0, column=3, padx=(0, 8)
        )
        ttk.Button(toolbar, text="Undo Last Boundary", style="Ghost.TButton", command=self.undo_last_boundary).grid(
            row=0, column=4, padx=(0, 8)
        )
        ttk.Button(toolbar, text="Finish Last Chapter at Book End", style="Ghost.TButton", command=self.finish_last_chapter_at_book_end).grid(
            row=0, column=5, padx=(0, 8)
        )
        ttk.Label(
            viewer_card,
            text="Left click to place the next boundary. The first click sets the first chapter start. Every later click sets the current chapter end and the next chapter start.",
            style="MutedCard.TLabel",
            wraplength=860,
        ).grid(row=2, column=0, sticky="w", pady=(10, 0))

        sidebar = ttk.Frame(content, style="Card.TFrame", padding=(14, 14, 14, 14))
        sidebar.grid(row=0, column=1, sticky="nsew")
        sidebar.rowconfigure(6, weight=1)
        sidebar.columnconfigure(0, weight=1)

        ttk.Label(sidebar, text="Current Chapter", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(sidebar, textvariable=self.chapter_var, style="StrongCard.TLabel", wraplength=460).grid(
            row=1, column=0, sticky="w", pady=(8, 0)
        )
        ttk.Label(sidebar, textvariable=self.output_var, style="MutedCard.TLabel", wraplength=460).grid(
            row=2, column=0, sticky="w", pady=(6, 0)
        )
        ttk.Label(sidebar, textvariable=self.page_var, style="CardBody.TLabel", wraplength=460).grid(
            row=3, column=0, sticky="w", pady=(10, 0)
        )
        ttk.Label(sidebar, textvariable=self.boundary_var, style="MutedCard.TLabel", wraplength=460).grid(
            row=4, column=0, sticky="w", pady=(6, 0)
        )
        ttk.Label(sidebar, textvariable=self.instructions_var, style="CardBody.TLabel", wraplength=460, justify=tk.LEFT).grid(
            row=5, column=0, sticky="ew", pady=(14, 12)
        )

        chapter_list_frame = ttk.Frame(sidebar, style="CardInner.TFrame")
        chapter_list_frame.grid(row=6, column=0, sticky="nsew")
        chapter_list_frame.rowconfigure(1, weight=1)
        chapter_list_frame.columnconfigure(0, weight=1)
        ttk.Label(chapter_list_frame, text="Chapter Outputs", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))

        tree_frame = ttk.Frame(chapter_list_frame, style="CardInner.TFrame")
        tree_frame.grid(row=1, column=0, sticky="nsew")
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)
        self.chapter_tree = ttk.Treeview(tree_frame, columns=("status", "chapter"), show="headings", selectmode="browse")
        self.chapter_tree.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.chapter_tree.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.chapter_tree.configure(yscrollcommand=scrollbar.set)
        self.chapter_tree.heading("status", text="Status")
        self.chapter_tree.heading("chapter", text="Chapter")
        self.chapter_tree.column("status", width=110, anchor=tk.W, stretch=False)
        self.chapter_tree.column("chapter", width=290, anchor=tk.W, stretch=True)
        self.chapter_tree.tag_configure("ready", foreground=SUCCESS_DARK)
        self.chapter_tree.tag_configure("active", foreground=WARNING_DARK)
        self.chapter_tree.tag_configure("waiting", foreground=ACCENT)
        self.chapter_tree.tag_configure("complete", foreground=SUCCESS_DARK)

        ttk.Label(sidebar, textvariable=self.export_var, style="MutedCard.TLabel", wraplength=460).grid(
            row=7, column=0, sticky="w", pady=(12, 0)
        )

    def _bind_events(self) -> None:
        self.root.bind("<Left>", lambda _event: self.go_previous_page())
        self.root.bind("<Right>", lambda _event: self.go_next_page())
        self.root.bind("<Control-z>", lambda _event: self.undo_last_boundary())
        self.root.bind("<Escape>", lambda _event: self.close())
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.canvas.bind("<Button-1>", self._on_canvas_click)
        self.canvas.bind("<Motion>", self._on_canvas_motion)
        self.canvas.bind("<Leave>", self._on_canvas_leave)
        self.canvas.bind("<Configure>", self._on_canvas_resize)

    def close(self) -> None:
        if self.current_image is not None:
            self.current_image.close()
            self.current_image = None
        self.root.destroy()

    def _initial_page_index(self) -> int:
        active = self._active_chapter_index()
        if active is None:
            last_boundary = self.boundaries[-1]
            if last_boundary is not None:
                return last_boundary.page_index
            return max(0, len(self.pages) - 1)

        if active == 0:
            start = self.boundaries[0]
            return 0 if start is None else start.page_index

        start = self.boundaries[active]
        if start is not None:
            return start.page_index
        previous = self.boundaries[active - 1]
        if previous is not None:
            return previous.page_index
        return 0

    def _active_chapter_index(self) -> int | None:
        for index in range(len(self.chapters)):
            if self.boundaries[index] is None or self.boundaries[index + 1] is None:
                return index
        return None

    def _current_stage(self) -> str:
        active = self._active_chapter_index()
        if active is None:
            return "complete"
        return "start" if self.boundaries[active] is None else "end"

    def _persist_state(self) -> None:
        self.state["boundaries"] = [serialize_boundary(boundary) for boundary in self.boundaries]
        save_chapter_split_state(self.state_path, self.state)

    def _show_current_page(self) -> None:
        page = self.pages[self.current_page_index]
        if self.current_image is not None:
            self.current_image.close()
        self.current_image = Image.open(page.page_path)
        self.tk_image = None
        self.cached_display_size = None
        self._render_current_page()

    def _render_current_page(self) -> None:
        if self.current_image is None:
            return

        canvas_width = max(1, self.canvas.winfo_width())
        canvas_height = max(1, self.canvas.winfo_height())
        image_width, image_height = self.current_image.size

        scale = min(canvas_width / image_width, canvas_height / image_height)
        scale = max(0.05, min(scale, 1.0))
        self.scale = scale
        display_width = max(1, int(round(image_width * scale)))
        display_height = max(1, int(round(image_height * scale)))
        self.offset_x = max(0, (canvas_width - display_width) // 2)
        self.offset_y = max(0, (canvas_height - display_height) // 2)

        if self.tk_image is None or self.cached_display_size != (display_width, display_height):
            display_image = self.current_image.resize((display_width, display_height), RESAMPLE_LANCZOS)
            self.tk_image = ImageTk.PhotoImage(display_image)
            self.cached_display_size = (display_width, display_height)

        self.canvas.delete("all")
        self.canvas.create_image(self.offset_x, self.offset_y, anchor=tk.NW, image=self.tk_image)

        page_left = self.offset_x
        page_right = self.offset_x + display_width

        active = self._active_chapter_index()
        for boundary_index, boundary in enumerate(self.boundaries):
            if boundary is None or boundary.page_index != self.current_page_index:
                continue

            canvas_y = self._image_y_to_canvas(boundary.y)
            color = LINE_DONE
            line_width = 2
            label = f"Boundary {boundary_index:02d}"

            if active is not None and boundary_index == active:
                color = LINE_CURRENT_START
                line_width = 3
                label = "Current start"
            elif active is not None and boundary_index == active + 1:
                color = LINE_CURRENT_END
                line_width = 3
                label = "Current end"

            self.canvas.create_line(page_left, canvas_y, page_right, canvas_y, fill=color, width=line_width)
            self.canvas.create_text(
                page_left + 12,
                max(self.offset_y + 10, canvas_y - 10),
                anchor=tk.NW,
                text=label,
                fill=color,
                font=("TkDefaultFont", 10, "bold"),
            )

        if self.hover_y is not None:
            canvas_y = self._image_y_to_canvas(self.hover_y)
            self.canvas.create_line(page_left, canvas_y, page_right, canvas_y, fill=GUIDE, width=2, dash=(6, 4))

        self._update_page_labels()
        self._update_chapter_tree()

    def _update_page_labels(self) -> None:
        active = self._active_chapter_index()
        page = self.pages[self.current_page_index]
        self.progress_var.set(
            f"{self._ready_chapter_count()}/{len(self.chapters)} chapter PDFs fully bounded"
        )
        self.status_var.set(
            f"Viewing page {self.current_page_index + 1} of {len(self.pages)}  •  preview DPI {self.state.get('render_dpi', 120)}"
        )
        self.page_var.set(f"{page.page_path.name}  •  {page.width} × {page.height}px")

        if active is None:
            self.chapter_var.set("All chapter boundaries are defined")
            self.output_var.set("You can export chapter PDFs now or close the app.")
            self.instructions_var.set(
                "All chapter boundaries are in place. Export PDFs to write the per-chapter files listed in book.json. You can still undo the last boundary if you need to step back."
            )
            self.boundary_var.set(self._boundary_summary())
            self.export_button.configure(state=tk.NORMAL)
            return

        chapter = self.chapters[active]
        stage = self._current_stage()
        start = self.boundaries[active]
        self.chapter_var.set(f"{chapter.index + 1:02d}. {chapter.title}  ({chapter.id})")
        self.output_var.set(f"Output PDF: {chapter.output_pdf}")

        if stage == "start":
            self.instructions_var.set(
                f"Click the horizontal line where {chapter.title} begins. That line becomes the top boundary for this chapter."
            )
        else:
            self.instructions_var.set(
                f"Click the horizontal line where {chapter.title} ends. That same line will also become the start of the next chapter."
            )

        start_text = "Start boundary: not set"
        if start is not None:
            start_text = f"Start boundary: page {start.page_index + 1}, y={start.y}px"
        self.boundary_var.set(f"{start_text}  •  {self._boundary_summary()}")
        self.export_button.configure(state=tk.DISABLED)

    def _boundary_summary(self) -> str:
        placed = sum(1 for boundary in self.boundaries if boundary is not None)
        return f"{placed}/{len(self.boundaries)} boundaries placed"

    def _ready_chapter_count(self) -> int:
        ready = 0
        for chapter_index in range(len(self.chapters)):
            if self.boundaries[chapter_index] is not None and self.boundaries[chapter_index + 1] is not None:
                ready += 1
        return ready

    def _update_chapter_tree(self) -> None:
        active = self._active_chapter_index()
        for item in self.chapter_tree.get_children():
            self.chapter_tree.delete(item)

        for chapter in self.chapters:
            status_text = "Waiting"
            tag = "waiting"
            has_start = self.boundaries[chapter.index] is not None
            has_end = self.boundaries[chapter.index + 1] is not None
            if has_start and has_end:
                status_text = "Ready"
                tag = "ready"
            elif active is not None and chapter.index == active:
                status_text = "Set end" if has_start else "Set start"
                tag = "active"
            elif active is None:
                status_text = "Ready"
                tag = "complete"

            self.chapter_tree.insert(
                "",
                tk.END,
                iid=str(chapter.index),
                values=(status_text, chapter.title),
                tags=(tag,),
            )

        if active is not None:
            self.chapter_tree.selection_set(str(active))
            self.chapter_tree.see(str(active))

        exported_at = self.state.get("last_exported_at")
        if exported_at:
            self.export_var.set(f"Last export: {exported_at}")
        else:
            self.export_var.set("No chapter PDFs have been exported from this splitter yet.")

        self.prev_button.configure(state=tk.NORMAL if self.current_page_index > 0 else tk.DISABLED)
        self.next_button.configure(state=tk.NORMAL if self.current_page_index < len(self.pages) - 1 else tk.DISABLED)

    def _on_canvas_resize(self, _event: tk.Event[tk.Misc]) -> None:
        if self.current_image is not None:
            self._render_current_page()

    def _on_canvas_motion(self, event: tk.Event[tk.Misc]) -> None:
        y_value = self._canvas_y_to_image(event.y)
        if y_value is None:
            if self.hover_y is not None:
                self.hover_y = None
                self._render_current_page()
            return
        if self.hover_y != y_value:
            self.hover_y = y_value
            self._render_current_page()

    def _on_canvas_leave(self, _event: tk.Event[tk.Misc]) -> None:
        if self.hover_y is not None:
            self.hover_y = None
            self._render_current_page()

    def _on_canvas_click(self, event: tk.Event[tk.Misc]) -> None:
        y_value = self._canvas_y_to_image(event.y)
        if y_value is None:
            return
        self.place_boundary(ChapterBoundary(page_index=self.current_page_index, y=y_value))

    def _canvas_y_to_image(self, canvas_y: int) -> int | None:
        if self.current_image is None:
            return None
        image_height = self.current_image.size[1]
        display_height = self.cached_display_size[1] if self.cached_display_size is not None else 0
        if canvas_y < self.offset_y or canvas_y > self.offset_y + display_height:
            return None
        image_y = int(round((canvas_y - self.offset_y) / max(self.scale, 1e-6)))
        return max(0, min(image_y, image_height))

    def _image_y_to_canvas(self, image_y: int) -> int:
        return int(round(self.offset_y + image_y * self.scale))

    def go_previous_page(self) -> None:
        if self.current_page_index <= 0:
            return
        self.current_page_index -= 1
        self._show_current_page()

    def go_next_page(self) -> None:
        if self.current_page_index >= len(self.pages) - 1:
            return
        self.current_page_index += 1
        self._show_current_page()

    def use_top_of_page(self) -> None:
        self.place_boundary(ChapterBoundary(page_index=self.current_page_index, y=0))

    def use_bottom_of_page(self) -> None:
        page = self.pages[self.current_page_index]
        self.place_boundary(ChapterBoundary(page_index=self.current_page_index, y=page.height))

    def finish_last_chapter_at_book_end(self) -> None:
        active = self._active_chapter_index()
        if active is None:
            messagebox.showinfo("Chapter Split", "All chapter boundaries are already defined.")
            return
        if active != len(self.chapters) - 1 or self.boundaries[active] is None:
            messagebox.showinfo(
                "Chapter Split",
                "This shortcut is only available once the last chapter has a start boundary and you want it to run to the end of the book.",
            )
            return

        last_page = self.pages[-1]
        self.boundaries[-1] = ChapterBoundary(page_index=last_page.page_index, y=last_page.height)
        self._persist_state()
        self.current_page_index = last_page.page_index
        self._show_current_page()
        messagebox.showinfo("Chapter Split", "The last chapter now ends at the bottom of the book.")

    def undo_last_boundary(self) -> None:
        for index in range(len(self.boundaries) - 1, -1, -1):
            if self.boundaries[index] is None:
                continue
            self.boundaries[index] = None
            self.state["last_exported_at"] = None
            self._persist_state()
            active = self._active_chapter_index()
            if active is None:
                self.current_page_index = max(0, len(self.pages) - 1)
            elif self.boundaries[active] is not None:
                self.current_page_index = self.boundaries[active].page_index
            elif active > 0 and self.boundaries[active - 1] is not None:
                self.current_page_index = self.boundaries[active - 1].page_index
            else:
                self.current_page_index = 0
            self._show_current_page()
            return
        messagebox.showinfo("Chapter Split", "No boundaries have been placed yet.")

    def place_boundary(self, candidate: ChapterBoundary) -> None:
        active = self._active_chapter_index()
        if active is None:
            messagebox.showinfo("Chapter Split", "All chapter boundaries are already defined. Export PDFs or undo a boundary to make a change.")
            return

        page = self.pages[candidate.page_index]
        candidate = ChapterBoundary(page_index=candidate.page_index, y=max(0, min(candidate.y, page.height)))
        stage = self._current_stage()

        if stage == "start":
            if active > 0:
                messagebox.showerror(
                    "Chapter Split",
                    "This chapter already inherits its start from the previous chapter end. Use Undo Last Boundary if you need to step backward.",
                )
                return
            self.boundaries[active] = candidate
        else:
            start = self.boundaries[active]
            if start is None:
                messagebox.showerror("Chapter Split", "Set the chapter start boundary first.")
                return
            if not _boundary_is_after(candidate, start):
                messagebox.showerror(
                    "Chapter Split",
                    "The chapter end boundary must come after the start boundary in reading order.",
                )
                return
            self.boundaries[active + 1] = candidate

        self.state["last_exported_at"] = None
        self._persist_state()

        next_active = self._active_chapter_index()
        if next_active is None:
            self.current_page_index = candidate.page_index
            self._show_current_page()
            messagebox.showinfo(
                "Chapter Split",
                "All chapter boundaries are now defined. Click Export PDFs to write the chapter files.",
            )
            return

        if self.boundaries[next_active] is not None:
            self.current_page_index = self.boundaries[next_active].page_index
        else:
            self.current_page_index = candidate.page_index
        self._show_current_page()

    def export_pdfs(self) -> None:
        if self._active_chapter_index() is not None:
            messagebox.showerror(
                "Chapter Split",
                "You still have chapter boundaries left to place before the PDFs can be exported.",
            )
            return

        try:
            output_paths = export_chapter_pdfs_from_state(self.state_path)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Chapter Split", str(exc))
            return

        self.state = load_chapter_split_state(self.state_path)
        self._render_current_page()
        summary = "\n".join(str(path) for path in output_paths[:8])
        if len(output_paths) > 8:
            summary += "\n..."
        messagebox.showinfo(
            "Chapter Split",
            f"Exported {len(output_paths)} chapter PDF files.\n\n{summary}",
        )


def launch_chapter_split_app(state_path: str | Path) -> Path:
    state_path = Path(state_path).resolve()
    app = ChapterSplitApp(state_path)
    app.run()
    return state_path
