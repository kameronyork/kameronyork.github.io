from __future__ import annotations

from pathlib import Path

import fitz
from PIL import Image
from tqdm import tqdm


def render_pdf_to_images(pdf_path: str | Path, output_dir: str | Path, dpi: int = 300) -> list[Path]:
    pdf_path = Path(pdf_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    doc = fitz.open(pdf_path)
    scale = dpi / 72.0
    matrix = fitz.Matrix(scale, scale)

    paths: list[Path] = []
    for page_index in tqdm(range(len(doc)), desc=f"Rendering {pdf_path.name}", unit="page", leave=False):
        page = doc[page_index]
        pix = page.get_pixmap(matrix=matrix, alpha=False)
        image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        out_path = output_dir / f"page-{page_index + 1:04d}.png"
        image.save(out_path)
        paths.append(out_path)

    return paths