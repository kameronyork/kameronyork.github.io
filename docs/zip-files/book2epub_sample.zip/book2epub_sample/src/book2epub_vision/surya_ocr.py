from __future__ import annotations

from pathlib import Path
from typing import Any

from PIL import Image
from tqdm import tqdm

from .models import OCRLine, PageOCR
from .surya_io import run_surya_ocr


def _page_lookup(results: dict[str, Any], image_name: str) -> dict[str, Any]:
    stem = Path(image_name).stem
    if stem in results:
        value = results[stem]
        if isinstance(value, list):
            return value[0]
        return value

    for key, value in results.items():
        if Path(key).stem == stem:
            if isinstance(value, list):
                return value[0]
            return value

    raise KeyError(f"No Surya OCR result found for image '{image_name}'.")


def _bbox_dims(bbox: list[float] | tuple[float, float, float, float]) -> tuple[int, int, int, int]:
    x1, y1, x2, y2 = [int(round(v)) for v in bbox]
    return x1, y1, max(0, x2 - x1), max(0, y2 - y1)


def ocr_chapter_images_with_surya(
    image_paths: list[Path],
    ocr_dir: Path,
    command: str = "surya_ocr",
) -> list[PageOCR]:
    ocr_dir.mkdir(parents=True, exist_ok=True)
    results = run_surya_ocr(input_path=image_paths[0].parent, output_dir=ocr_dir, command=command)

    pages: list[PageOCR] = []
    for page_index, image_path in enumerate(tqdm(image_paths, desc="OCR", unit="page", leave=False)):
        page_result = _page_lookup(results, image_path.name)
        image = Image.open(image_path)
        width, height = image.size
        lines: list[OCRLine] = []

        for line_index, item in enumerate(page_result.get("text_lines", []), start=1):
            text = (item.get("text") or "").strip()
            bbox = item.get("bbox")
            if not text or not bbox:
                continue
            left, top, line_width, line_height = _bbox_dims(bbox)
            confidence = float(item.get("confidence", 0.0)) * 100.0
            lines.append(
                OCRLine(
                    page_index=page_index,
                    block_num=1,
                    par_num=1,
                    line_num=line_index,
                    left=left,
                    top=top,
                    width=line_width,
                    height=line_height,
                    conf=confidence,
                    text=text,
                )
            )

        pages.append(PageOCR(page_index=page_index, width=width, height=height, lines=lines))

    return pages