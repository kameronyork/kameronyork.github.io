# book2epub_vision_crop

This repo is a **new pipeline** built around a **local AI document model** for page cropping.

The flow is:

1. Render scanned PDF pages to PNG.
2. Run **Surya layout detection** on the page images.
3. Build a body-text crop box from the detected text/layout boxes.
4. Save cropped page images.
5. Run **Surya OCR** on the cropped images.
6. Rebuild paragraphs across page boundaries.
7. Package everything into one reflowable EPUB.

This repo is designed for exactly the case you described:
- chapter PDFs scanned from physical books
- pages that are mostly regular, but text body size/placement can vary
- chapter-ending pages that may stop mid-page
- page headers and page numbers that should be excluded from the readable EPUB

## What has been added since the original version

The biggest change is that the repo no longer expects you to trust the automatic crop blindly.

It now supports a **manual crop review workflow**:

- `crop` still prepares the book for cropping, but now also opens a review app
- `prepare-crop` prepares all rendered pages and suggested crop boxes **without** opening the app
- `cropApp` opens the crop review app by itself using already-prepared pages/suggestions
- `review` can also reopen the review app later
- the app lets you **Approve**, **Edit**, **go Back**, **Reset to Suggestion**, and **Unapprove**
- the app includes a secondary browser view with:
  - an **Uncropped** tab
  - a **Cropped** tab

This means the intended workflow is now:

1. Prepare pages and suggested crops for all configured chapters.
2. Review every page in the crop app.
3. Approve or edit the crop boxes you want.
4. Build the EPUB from the reviewed crops.

That change was made specifically to avoid cases where the automatic crop occasionally misses a top line or includes a page number/header.

## What you install

You need:

- Python 3.11+
- A local Surya install
- Enough disk space for temporary page images and model weights

Surya's official docs say it supports OCR, layout analysis, and reading order, and that model weights download automatically on first run. It also exposes `surya_layout` and `surya_ocr` commands and supports Python 3.10+. See the official project page and PyPI page for current installation details.

## Windows install

Open PowerShell **inside the repo folder**.

### 1) Create and activate a virtual environment

    python -m venv .venv
    .venv\Scripts\Activate.ps1

If activation is blocked:

    Set-ExecutionPolicy -Scope Process Bypass
    .venv\Scripts\Activate.ps1

### 2) Install a local CPU PyTorch build

Use the current CPU install command from the official PyTorch site.

### 3) Install Surya

    pip install surya-ocr

### 4) Install this repo

    pip install -e .

### 5) Verify the commands exist

    surya_layout --help
    surya_ocr --help
    vision2epub --help

## Exactly where to put your PDFs

Create this folder structure inside the repo:

    book2epub_vision_crop/
      input/
        hgttg/
          01-chapter-01.pdf
          02-chapter-02.pdf
          03-chapter-03.pdf
          ...
          10-chapter-10.pdf

## Your first real test

Do **not** start with all 10 chapters.

Start with just one PDF:

    input/hgttg/01-chapter-01.pdf

Then edit `examples/book.json` so it contains only that one chapter entry.

## The config file

The example config lives here:

    examples/book.json

Important path rule:
- if your config stays inside `examples/`, then chapter paths should start with `../input/...`
- if you move the config to the repo root, then paths can start with `input/...`

## Run only the render + crop-prep stage

This is still the best first debug step when you are tuning crop behavior:

    vision2epub crop examples/book.json

This now does two things:
1. prepares all rendered page images and suggested crop boxes
2. opens the crop review app

This creates:

    work/hgttg/chapter-01/pages/
    work/hgttg/chapter-01/layout/
    work/hgttg/chapter-01/cropped/

Inspect the results in the review app first.

If those cropped images look right, move on.

## Prepare crop suggestions without opening the app

If you want to do the prep work first and launch the app later:

    vision2epub prepare-crop examples/book.json

## Open the crop review app on its own

If the pages and suggested crops are already prepared, you can launch the app by itself:

    vision2epub cropApp examples/book.json

You can also reopen the app later with:

    vision2epub review examples/book.json

## Crop review app controls

The review app adds a manual verification step before long OCR/build runs.

Main actions:
- **Approve** — keep the current crop
- **Edit** — manually adjust the crop box
- **Back** — return to the previous page if you made a mistake
- **Reset to Suggestion** — restore the original suggested crop
- **Unapprove** — mark an approved page as not approved so you can fix it

The app also includes a secondary page browser with:
- an **Uncropped** tab
- a **Cropped** tab

That makes it easier to compare original pages against saved crops and jump around if you need to revisit mistakes.

## Assemble cropped images into PDFs

    vision2epub assemble examples/book.json

## Build the final EPUB

    vision2epub build examples/book.json

Output:

    output/hgttg.epub

## What gets written to disk

For each chapter, the repo creates:

    work/hgttg/chapter-01/
      pages/         # rendered PNGs from the PDF
      layout/        # crop suggestion metadata / raw crop data
      cropped/       # reviewed/saved cropped page PNGs
      ocr/           # raw Surya OCR JSON
      cleaned/       # merged cleaned text
      xhtml/         # chapter XHTML used inside the EPUB

Depending on the command flow, you may also see additional review-state files used by the crop app.

## Config knobs that matter most

### `crop_model.margin_px`
Adds a safety margin around the detected text body.

If letters are getting clipped, increase this.

### `crop_model.min_box_area_ratio`
Drops tiny layout boxes.

If page numbers are still slipping in, increase this a little.

### `crop_model.max_boxes`
Limits how many boxes are merged into the final crop region.

For ordinary prose pages, a modest value works well.

### `cleanup.drop_regexes`
Extra regexes to remove junk lines after OCR.

## Recommended workflow for your 10 chapter PDFs

1. Put all 10 chapter PDFs in `input/hgttg/`.
2. Start with **1 chapter** in the config.
3. Run `vision2epub crop examples/book.json`.
4. Review the suggested crops in the app.
5. Approve or edit each page as needed.
6. If you make a mistake, use **Back**, **Unapprove**, or reopen the browser view.
7. If the crops look good, run `vision2epub build examples/book.json`.
8. Open the resulting EPUB and spot-check paragraph flow.
9. Add the remaining chapters to the config.
10. Rebuild the full book.

If you want to split prep from review, you can do:

1. `vision2epub prepare-crop examples/book.json`
2. `vision2epub cropApp examples/book.json`
3. `vision2epub build examples/book.json`

## What this repo does better than the earlier one

The earlier starter relied on fixed percentage crops.

This repo uses a **local AI document model** to decide the body-text crop **per page**, which is much better for:

- pages where chapter text ends halfway down
- chapter-opening pages with unusual whitespace
- pages whose text block shifts vertically
- scans that are consistent overall but not identical page-to-page

It also now adds a **manual review layer** on top of that, which is better for:
- pages where a short top line could be missed
- pages where chapter headers or page numbers confuse the suggestion logic
- long OCR/build jobs where you want to verify crops first

## Limitations

- I have not benchmarked this exact repo end-to-end on your Windows machine.
- Surya model downloads happen the first time you run it.
- On CPU, Surya can be noticeably slower than fixed-crop + Tesseract.
- The repo assumes scanned prose pages, not comics or dense academic layouts.
- The automatic crop is now treated as a suggestion, not as the final authority.
- Final crop quality depends on the review step if you choose to edit or approve manually.

## If `surya_layout` or `surya_ocr` is not found

That means Surya did not install into the active virtual environment, or the shell is not using the right venv.

Try:

    python -m pip install surya-ocr
    python -m pip show surya-ocr

Then re-open PowerShell, reactivate the venv, and test again.

## If the crop app does not open

First make sure you already prepared the pages and crop suggestions.

Try:

    vision2epub cropApp examples/book.json

If that still fails, rerun the prep stage:

    vision2epub prepare-crop examples/book.json

Then try `cropApp` again.